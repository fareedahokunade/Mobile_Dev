import 'package:flutter/material.dart';
import 'package:ccbyalu/presentation/splash_page_screen/splash_page_screen.dart';
import 'package:ccbyalu/presentation/home_page_screen/home_page_screen.dart';
import 'package:ccbyalu/presentation/log_in_screen/log_in_screen.dart';
import 'package:ccbyalu/presentation/help_screen/help_screen.dart';
import 'package:ccbyalu/presentation/notifications_screen/notifications_screen.dart';
import 'package:ccbyalu/presentation/filter_one_screen/filter_one_screen.dart';
import 'package:ccbyalu/presentation/booking_form_screen/booking_form_screen.dart';
import 'package:ccbyalu/presentation/filter_screen/filter_screen.dart';
import 'package:ccbyalu/presentation/booking_form_one_screen/booking_form_one_screen.dart';
import 'package:ccbyalu/presentation/add_event_screen/add_event_screen.dart';
import 'package:ccbyalu/presentation/profile_screen/profile_screen.dart';
import 'package:ccbyalu/presentation/my_bookings_screen/my_bookings_screen.dart';
import 'package:ccbyalu/presentation/sign_up_screen/sign_up_screen.dart';
import 'package:ccbyalu/presentation/start_overlay_screen/start_overlay_screen.dart';
import 'package:ccbyalu/presentation/splash_page_one_screen/splash_page_one_screen.dart';
import 'package:ccbyalu/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String splashPageScreen = '/splash_page_screen';

  static const String homePageScreen = '/home_page_screen';

  static const String logInScreen = '/log_in_screen';

  static const String helpScreen = '/help_screen';

  static const String notificationsScreen = '/notifications_screen';

  static const String filterOneScreen = '/filter_one_screen';

  static const String bookingFormScreen = '/booking_form_screen';

  static const String filterScreen = '/filter_screen';

  static const String bookingFormOneScreen = '/booking_form_one_screen';

  static const String addEventScreen = '/add_event_screen';

  static const String profileScreen = '/profile_screen';

  static const String myBookingsScreen = '/my_bookings_screen';

  static const String signUpScreen = '/sign_up_screen';

  static const String startOverlayScreen = '/start_overlay_screen';

  static const String splashPageOneScreen = '/splash_page_one_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    splashPageScreen: (context) => SplashPageScreen(),
    homePageScreen: (context) => HomePageScreen(),
    logInScreen: (context) => LogInScreen(),
    helpScreen: (context) => HelpScreen(),
    notificationsScreen: (context) => NotificationsScreen(),
    filterOneScreen: (context) => FilterOneScreen(),
    bookingFormScreen: (context) => BookingFormScreen(),
    filterScreen: (context) => FilterScreen(),
    bookingFormOneScreen: (context) => BookingFormOneScreen(),
    addEventScreen: (context) => AddEventScreen(),
    profileScreen: (context) => ProfileScreen(),
    myBookingsScreen: (context) => MyBookingsScreen(),
    signUpScreen: (context) => SignUpScreen(),
    startOverlayScreen: (context) => StartOverlayScreen(),
    splashPageOneScreen: (context) => SplashPageOneScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
