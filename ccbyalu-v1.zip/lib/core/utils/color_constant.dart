import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color deepOrange50 = fromHex('#fceaea');

  static Color cyanA200 = fromHex('#1ff7fd');

  static Color amber30075 = fromHex('#75f2c94c');

  static Color deepOrange40001 = fromHex('#fe834b');

  static Color gray5003f = fromHex('#3f9e9e9e');

  static Color black9003f = fromHex('#3f000000');

  static Color gray50 = fromHex('#f8f8f8');

  static Color red50 = fromHex('#ffebeb');

  static Color red100 = fromHex('#fed2d2');

  static Color teal400 = fromHex('#22bb9b');

  static Color blueA1007e = fromHex('#7e7eb1fb');

  static Color black900 = fromHex('#000000');

  static Color green30075 = fromHex('#757ae467');

  static Color blueGray900 = fromHex('#40272e');

  static Color purpleA200 = fromHex('#b23bf5');

  static Color deepOrange400 = fromHex('#ff844b');

  static Color black90047 = fromHex('#47000000');

  static Color gray90002 = fromHex('#0d1c2e');

  static Color blueGray100 = fromHex('#d9d9d9');

  static Color gray500 = fromHex('#979797');

  static Color blueGray300 = fromHex('#8e9cb6');

  static Color gray900 = fromHex('#181d2d');

  static Color gray90001 = fromHex('#292929');

  static Color blue50 = fromHex('#e5f3fb');

  static Color bluegray400 = fromHex('#888888');

  static Color indigo50099 = fromHex('#99365fbe');

  static Color whiteA700 = fromHex('#ffffff');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
