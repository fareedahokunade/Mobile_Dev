class ImageConstant {
  static String imgBase = 'assets/images/img_base.png';

  static String imgCube = 'assets/images/img_cube.png';

  static String imgToyfacestansparentbg49 =
      'assets/images/img_toyfacestansparentbg49.png';

  static String imgMoumtain = 'assets/images/img_moumtain.png';

  static String imgSpecular30x26 = 'assets/images/img_specular_30x26.png';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgRectangle1444 = 'assets/images/img_rectangle1444.png';

  static String imgEllipse756157x375 =
      'assets/images/img_ellipse756_157x375.png';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgCube59x38 = 'assets/images/img_cube_59x38.png';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgEllipse7563 = 'assets/images/img_ellipse756_3.png';

  static String imgLocationGray500 = 'assets/images/img_location_gray_500.svg';

  static String imgEllipse7564 = 'assets/images/img_ellipse756_4.png';

  static String imgAirplane = 'assets/images/img_airplane.svg';

  static String img1 = 'assets/images/img_1.png';

  static String imgEllipse7562 = 'assets/images/img_ellipse756_2.png';

  static String imgIcons8door481 = 'assets/images/img_icons8door481.png';

  static String img2 = 'assets/images/img_2.png';

  static String imgEllipse756 = 'assets/images/img_ellipse756.png';

  static String imgSpecular59x38 = 'assets/images/img_specular_59x38.png';

  static String imgFrame = 'assets/images/img_frame.svg';

  static String imgSpecular = 'assets/images/img_specular.png';

  static String imgJournalism1 = 'assets/images/img_journalism1.png';

  static String imgIcons8creditcard48 =
      'assets/images/img_icons8creditcard48.png';

  static String imgMin = 'assets/images/img_min.png';

  static String imgLightbulb = 'assets/images/img_lightbulb.svg';

  static String imgFilterWhiteA700 = 'assets/images/img_filter_white_a700.png';

  static String imgCircles = 'assets/images/img_circles.png';

  static String imgShadow1 = 'assets/images/img_shadow_1.png';

  static String imgBookmark = 'assets/images/img_bookmark.svg';

  static String imgBase30x26 = 'assets/images/img_base_30x26.png';

  static String imgGraphic455x375 = 'assets/images/img_graphic_455x375.png';

  static String imgIcons8tearoffcalendar48 =
      'assets/images/img_icons8tearoffcalendar48.png';

  static String imgHr = 'assets/images/img_hr.png';

  static String imgIconassignment = 'assets/images/img_iconassignment.svg';

  static String imgPlay = 'assets/images/img_play.svg';

  static String imgGroup42 = 'assets/images/img_group42.svg';

  static String imgIconsboldmedal = 'assets/images/img_iconsboldmedal.svg';

  static String imgShadow14x37 = 'assets/images/img_shadow_14x37.png';

  static String imgSpecular59x35 = 'assets/images/img_specular_59x35.png';

  static String imgImage1 = 'assets/images/img_image1.png';

  static String imgShadow21x107 = 'assets/images/img_shadow_21x107.png';

  static String imgShadow21x46 = 'assets/images/img_shadow_21x46.png';

  static String imgFilter = 'assets/images/img_filter.png';

  static String imgEllipse756571x375 =
      'assets/images/img_ellipse756_571x375.png';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgEllipse7565 = 'assets/images/img_ellipse756_5.png';

  static String imgShadow = 'assets/images/img_shadow.png';

  static String imgGraphic = 'assets/images/img_graphic.png';

  static String imgKisspngchinab = 'assets/images/img_kisspngchinab.png';

  static String imgGroup38 = 'assets/images/img_group38.png';

  static String imgEllipse7561 = 'assets/images/img_ellipse756_1.png';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgImage = 'assets/images/img_image.png';

  static String imgRectangle144420x375 =
      'assets/images/img_rectangle1444_20x375.png';

  static String imgShadow21x83 = 'assets/images/img_shadow_21x83.png';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgBookmarkWhiteA700 =
      'assets/images/img_bookmark_white_a700.svg';

  static String imgBookmarkWhiteA70026x16 =
      'assets/images/img_bookmark_white_a700_26x16.svg';

  static String imgShadow21x94 = 'assets/images/img_shadow_21x94.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
