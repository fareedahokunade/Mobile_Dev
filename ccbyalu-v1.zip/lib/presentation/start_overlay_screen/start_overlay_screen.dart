import '../start_overlay_screen/widgets/listfrifebseventeen_one_item_widget.dart';
import '../start_overlay_screen/widgets/listtoday_item_widget.dart';
import 'package:ccbyalu/core/app_export.dart';
import 'package:flutter/material.dart';

class StartOverlayScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: getVerticalSize(287.00),
                width: size.width,
                child: Stack(alignment: Alignment.bottomCenter, children: [
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          height: getVerticalSize(32.00),
                          width: size.width,
                          margin: getMargin(top: 118),
                          decoration:
                              BoxDecoration(color: ColorConstant.blueGray100))),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                          width: size.width,
                          padding: getPadding(
                              left: 21, top: 11, right: 21, bottom: 11),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder35),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(left: 9, right: 7),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        children: [
                                          CustomImageView(
                                              svgPath: ImageConstant.imgFrame,
                                              height: getVerticalSize(7.00),
                                              width: getHorizontalSize(22.00),
                                              margin: getMargin(top: 6)),
                                          Spacer(flex: 45),
                                          Container(
                                              height: getVerticalSize(8.00),
                                              width: getHorizontalSize(40.00),
                                              margin: getMargin(bottom: 6),
                                              decoration: BoxDecoration(
                                                  color:
                                                      ColorConstant.gray90002,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              4.00)))),
                                          Spacer(flex: 54),
                                          CustomImageView(
                                              svgPath:
                                                  ImageConstant.imgLightbulb,
                                              height: getVerticalSize(7.00),
                                              width: getHorizontalSize(22.00),
                                              margin: getMargin(top: 6),
                                              onTap: () {
                                                onTapImgLightbulb(context);
                                              })
                                        ])),
                                Container(
                                    height: getVerticalSize(238.00),
                                    width: getHorizontalSize(331.00),
                                    margin: getMargin(top: 10),
                                    child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Align(
                                              alignment: Alignment.topCenter,
                                              child: Padding(
                                                  padding: getPadding(
                                                      left: 128,
                                                      top: 18,
                                                      right: 123),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        Padding(
                                                            padding: getPadding(
                                                                left: 9),
                                                            child: Text(
                                                                "Welcome",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtZCOOLXiaoWeiRegular14)),
                                                        Padding(
                                                            padding: getPadding(
                                                                left: 6,
                                                                top: 3),
                                                            child: Text(
                                                                "Aimar M.",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtZCOOLXiaoWeiRegular16WhiteA700)),
                                                        Container(
                                                            height:
                                                                getVerticalSize(
                                                                    25.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    80.00),
                                                            margin: getMargin(
                                                                top: 81),
                                                            decoration: BoxDecoration(
                                                                color: ColorConstant
                                                                    .whiteA700))
                                                      ]))),
                                          Align(
                                              alignment: Alignment.center,
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Padding(
                                                        padding: getPadding(
                                                            left: 8, right: 93),
                                                        child:
                                                            ListView.separated(
                                                                physics:
                                                                    BouncingScrollPhysics(),
                                                                shrinkWrap:
                                                                    true,
                                                                separatorBuilder:
                                                                    (context,
                                                                        index) {
                                                                  return SizedBox(
                                                                      height: getVerticalSize(
                                                                          16.00));
                                                                },
                                                                itemCount: 3,
                                                                itemBuilder:
                                                                    (context,
                                                                        index) {
                                                                  return ListtodayItemWidget();
                                                                })),
                                                    Container(
                                                        margin:
                                                            getMargin(top: 12),
                                                        padding: getPadding(
                                                            left: 6,
                                                            top: 5,
                                                            right: 6,
                                                            bottom: 5),
                                                        decoration: AppDecoration
                                                            .fillBluegray100
                                                            .copyWith(
                                                                borderRadius:
                                                                    BorderRadiusStyle
                                                                        .roundedBorder17),
                                                        child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          left:
                                                                              2,
                                                                          top:
                                                                              1,
                                                                          bottom:
                                                                              1),
                                                                  child: Text(
                                                                      "Wed Feb 15",
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtZCOOLXiaoWeiRegular20Gray900)),
                                                              Spacer(flex: 50),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              3),
                                                                  child: Text(
                                                                      "16",
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtZCOOLXiaoWeiRegular20Gray900)),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          left:
                                                                              43,
                                                                          top:
                                                                              3),
                                                                  child: Text(
                                                                      "30",
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtZCOOLXiaoWeiRegular20Gray900)),
                                                              Spacer(flex: 49),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              2,
                                                                          bottom:
                                                                              1),
                                                                  child: Text(
                                                                      "AM",
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtZCOOLXiaoWeiRegular20Gray900))
                                                            ])),
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Padding(
                                                            padding: getPadding(
                                                                left: 9,
                                                                top: 4,
                                                                right: 8),
                                                            child: ListView
                                                                .separated(
                                                                    physics:
                                                                        BouncingScrollPhysics(),
                                                                    shrinkWrap:
                                                                        true,
                                                                    separatorBuilder:
                                                                        (context,
                                                                            index) {
                                                                      return SizedBox(
                                                                          height:
                                                                              getVerticalSize(13.00));
                                                                    },
                                                                    itemCount:
                                                                        3,
                                                                    itemBuilder:
                                                                        (context,
                                                                            index) {
                                                                      return ListfrifebseventeenOneItemWidget();
                                                                    })))
                                                  ]))
                                        ])),
                                Spacer(),
                                Align(
                                    alignment: Alignment.centerRight,
                                    child: Container(
                                        width: getHorizontalSize(30.00),
                                        margin: getMargin(right: 116),
                                        padding: getPadding(left: 2, right: 2),
                                        decoration: AppDecoration.fillGray50
                                            .copyWith(
                                                borderRadius: BorderRadiusStyle
                                                    .roundedBorder17),
                                        child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.end,
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              Container(
                                                  height: getSize(22.00),
                                                  width: getSize(22.00),
                                                  margin: getMargin(top: 7),
                                                  decoration: BoxDecoration(
                                                      color: ColorConstant
                                                          .green30075,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              getHorizontalSize(
                                                                  11.00))))
                                            ]))),
                                Padding(
                                    padding: getPadding(top: 215, bottom: 29),
                                    child: Text("Home",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                        style: AppStyle
                                            .txtZCOOLXiaoWeiRegular10WhiteA700))
                              ])))
                ]))));
  }

  onTapImgLightbulb(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.notificationsScreen);
  }
}
