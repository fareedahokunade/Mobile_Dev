import 'package:ccbyalu/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListfrifebseventeenOneItemWidget extends StatelessWidget {
  ListfrifebseventeenOneItemWidget();

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: getPadding(
              bottom: 3,
            ),
            child: Text(
              "Fri Feb 17",
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.left,
              style: AppStyle.txtZCOOLXiaoWeiRegular20Gray900,
            ),
          ),
          Spacer(
            flex: 53,
          ),
          Padding(
            padding: getPadding(
              bottom: 3,
            ),
            child: Text(
              "17",
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.left,
              style: AppStyle.txtZCOOLXiaoWeiRegular20Gray900,
            ),
          ),
          Padding(
            padding: getPadding(
              left: 43,
              bottom: 3,
            ),
            child: Text(
              "31",
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.left,
              style: AppStyle.txtZCOOLXiaoWeiRegular20Gray900,
            ),
          ),
          Spacer(
            flex: 46,
          ),
          Padding(
            padding: getPadding(
              top: 3,
            ),
            child: Text(
              "PM",
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.left,
              style: AppStyle.txtZCOOLXiaoWeiRegular20Gray900,
            ),
          ),
        ],
      ),
    );
  }
}
