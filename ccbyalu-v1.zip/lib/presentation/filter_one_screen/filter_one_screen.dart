import 'package:ccbyalu/core/app_export.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_image.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_subtitle.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_subtitle_1.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_subtitle_2.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_title.dart';
import 'package:ccbyalu/widgets/app_bar/custom_app_bar.dart';
import 'package:ccbyalu/widgets/custom_drop_down.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class FilterOneScreen extends StatelessWidget {
  List<String> dropdownItemList = ["Item One", "Item Two", "Item Three"];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: size.height,
                width: size.width,
                child: Stack(alignment: Alignment.topRight, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          width: size.width,
                          padding: getPadding(top: 8, bottom: 8),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder35),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomAppBar(
                                    height: getVerticalSize(66.00),
                                    title: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Padding(
                                              padding: getPadding(
                                                  left: 16, right: 98),
                                              child: Row(children: [
                                                Container(
                                                    height:
                                                        getVerticalSize(50.36),
                                                    width: getHorizontalSize(
                                                        35.14),
                                                    child: Stack(
                                                        alignment:
                                                            Alignment.center,
                                                        children: [
                                                          AppbarImage(
                                                              height: getSize(
                                                                  22.00),
                                                              width: getSize(
                                                                  22.00),
                                                              svgPath:
                                                                  ImageConstant
                                                                      .imgFrame,
                                                              margin: getMargin(
                                                                  left: 13,
                                                                  top: 28)),
                                                          AppbarTitle(
                                                              text: "x",
                                                              margin: getMargin(
                                                                  right: 19,
                                                                  bottom: 15))
                                                        ])),
                                                Container(
                                                    height:
                                                        getVerticalSize(43.32),
                                                    width: getHorizontalSize(
                                                        199.12),
                                                    margin: getMargin(
                                                        left: 25,
                                                        top: 3,
                                                        bottom: 3),
                                                    child: Stack(children: [
                                                      AppbarSubtitle2(
                                                          text: "Welcome",
                                                          margin: getMargin(
                                                              left: 81,
                                                              top: 29,
                                                              right: 62)),
                                                      Container(
                                                          height:
                                                              getVerticalSize(
                                                                  29.75),
                                                          width:
                                                              getHorizontalSize(
                                                                  199.12),
                                                          margin: getMargin(
                                                              bottom: 13),
                                                          child: Stack(
                                                              alignment: Alignment
                                                                  .bottomCenter,
                                                              children: [
                                                                AppbarSubtitle2(
                                                                    text:
                                                                        "Welcome",
                                                                    margin: getMargin(
                                                                        left: 3,
                                                                        top: 4,
                                                                        right:
                                                                            140,
                                                                        bottom:
                                                                            11)),
                                                                AppbarSubtitle1(
                                                                    text:
                                                                        "Aimar M.",
                                                                    margin: getMargin(
                                                                        top: 13,
                                                                        right:
                                                                            137)),
                                                                AppbarSubtitle(
                                                                    text:
                                                                        "Booking Filters",
                                                                    margin: getMargin(
                                                                        left:
                                                                            24)),
                                                                AppbarSubtitle2(
                                                                    text:
                                                                        "Welcome",
                                                                    margin: getMargin(
                                                                        left:
                                                                            83,
                                                                        top: 2,
                                                                        right:
                                                                            60,
                                                                        bottom:
                                                                            13)),
                                                                AppbarSubtitle1(
                                                                    text:
                                                                        "Aimar M.",
                                                                    margin: getMargin(
                                                                        left:
                                                                            80,
                                                                        top: 11,
                                                                        right:
                                                                            57,
                                                                        bottom:
                                                                            2)),
                                                                AppbarSubtitle(
                                                                    text:
                                                                        "Booking Filters",
                                                                    margin: getMargin(
                                                                        left:
                                                                            24)),
                                                                AppbarSubtitle2(
                                                                    text:
                                                                        "Welcome",
                                                                    margin: getMargin(
                                                                        left:
                                                                            83,
                                                                        top: 2,
                                                                        right:
                                                                            60,
                                                                        bottom:
                                                                            13)),
                                                                AppbarSubtitle1(
                                                                    text:
                                                                        "Aimar M.",
                                                                    margin: getMargin(
                                                                        left:
                                                                            80,
                                                                        top: 11,
                                                                        right:
                                                                            57,
                                                                        bottom:
                                                                            2)),
                                                                AppbarSubtitle(
                                                                    text:
                                                                        "Booking Filters",
                                                                    margin: getMargin(
                                                                        left:
                                                                            24))
                                                              ]))
                                                    ]))
                                              ])),
                                          AppbarSubtitle1(
                                              text: "Aimar M.",
                                              margin: getMargin(
                                                  left: 155, right: 157))
                                        ])),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                        padding: getPadding(left: 11, top: 50),
                                        child: Text("Start",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtAbhayaLibreExtraBold25Bluegray900))),
                                Padding(
                                    padding:
                                        getPadding(left: 20, top: 1, right: 34),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                              height: getVerticalSize(29.00),
                                              width: getHorizontalSize(209.00),
                                              child: Stack(
                                                  alignment: Alignment.topRight,
                                                  children: [
                                                    Align(
                                                        alignment: Alignment
                                                            .bottomLeft,
                                                        child: Text(
                                                            "02/13/2023 1:15PM",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtRobotoRegular16Black900
                                                                .copyWith(
                                                                    letterSpacing:
                                                                        getHorizontalSize(
                                                                            0.57)))),
                                                    Align(
                                                        alignment:
                                                            Alignment.topRight,
                                                        child: Container(
                                                            height:
                                                                getVerticalSize(
                                                                    25.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    80.00),
                                                            decoration: BoxDecoration(
                                                                color: ColorConstant
                                                                    .whiteA700)))
                                                  ])),
                                          CustomImageView(
                                              svgPath:
                                                  ImageConstant.imgArrowdown,
                                              height: getVerticalSize(8.00),
                                              width: getHorizontalSize(20.00),
                                              margin: getMargin(top: 20),
                                              onTap: () {
                                                onTapImgArrowdown(context);
                                              })
                                        ])),
                                Container(
                                    height: getVerticalSize(3.00),
                                    width: size.width,
                                    margin: getMargin(top: 18),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.blueGray100)),
                                Container(
                                    height: getVerticalSize(66.00),
                                    width: getHorizontalSize(345.00),
                                    margin: getMargin(top: 24),
                                    child: Stack(
                                        alignment: Alignment.bottomRight,
                                        children: [
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Text("Duration",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtAbhayaLibreExtraBold25Bluegray900),
                                                    Container(
                                                        height: getVerticalSize(
                                                            26.00),
                                                        width:
                                                            getHorizontalSize(
                                                                27.00),
                                                        margin: getMargin(
                                                            left: 20, top: 10),
                                                        decoration: BoxDecoration(
                                                            color: ColorConstant
                                                                .whiteA700,
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        13.00)),
                                                            border: Border.all(
                                                                color:
                                                                    ColorConstant
                                                                        .gray900,
                                                                width:
                                                                    getHorizontalSize(
                                                                        1.00))))
                                                  ])),
                                          Align(
                                              alignment: Alignment.bottomRight,
                                              child: Container(
                                                  height: getVerticalSize(3.00),
                                                  width:
                                                      getHorizontalSize(293.00),
                                                  margin: getMargin(bottom: 10),
                                                  decoration: BoxDecoration(
                                                      color: ColorConstant
                                                          .blueGray100)))
                                        ])),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                        padding: getPadding(left: 34, top: 13),
                                        child: Text("15mins",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtRobotoRegular16Black900
                                                .copyWith(
                                                    letterSpacing:
                                                        getHorizontalSize(
                                                            0.57))))),
                                Spacer(),
                                Container(
                                    height: getVerticalSize(68.00),
                                    width: getHorizontalSize(344.00),
                                    child: Stack(
                                        alignment: Alignment.bottomLeft,
                                        children: [
                                          Align(
                                              alignment: Alignment.topCenter,
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Text("Attendees",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtAbhayaLibreExtraBold25Bluegray900),
                                                    Align(
                                                        alignment: Alignment
                                                            .centerRight,
                                                        child: Container(
                                                            height:
                                                                getVerticalSize(
                                                                    3.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    293.00),
                                                            margin: getMargin(
                                                                top: 25),
                                                            decoration: BoxDecoration(
                                                                color: ColorConstant
                                                                    .blueGray100)))
                                                  ])),
                                          Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Container(
                                                  height:
                                                      getVerticalSize(26.00),
                                                  width:
                                                      getHorizontalSize(27.00),
                                                  margin: getMargin(left: 19),
                                                  decoration: BoxDecoration(
                                                      color: ColorConstant
                                                          .whiteA700,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              getHorizontalSize(
                                                                  13.00)),
                                                      border: Border.all(
                                                          color: ColorConstant
                                                              .gray900,
                                                          width:
                                                              getHorizontalSize(
                                                                  1.00)))))
                                        ])),
                                Align(
                                    alignment: Alignment.centerRight,
                                    child: Padding(
                                        padding: getPadding(
                                            left: 32, top: 1, right: 4),
                                        child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Padding(
                                                  padding: getPadding(top: 1),
                                                  child: Text("Any",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtRobotoRegular16Black900
                                                          .copyWith(
                                                              letterSpacing:
                                                                  getHorizontalSize(
                                                                      0.57)))),
                                              Padding(
                                                  padding:
                                                      getPadding(bottom: 1),
                                                  child: Text("50+",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtRobotoRegular16Black900
                                                          .copyWith(
                                                              letterSpacing:
                                                                  getHorizontalSize(
                                                                      0.57))))
                                            ]))),
                                GestureDetector(
                                    onTap: () {
                                      onTapTxtGroupFive(context);
                                    },
                                    child: Container(
                                        width: getHorizontalSize(314.00),
                                        margin: getMargin(top: 50),
                                        padding: getPadding(
                                            left: 30,
                                            top: 7,
                                            right: 123,
                                            bottom: 7),
                                        decoration: AppDecoration
                                            .txtFillGray90002
                                            .copyWith(
                                                borderRadius: BorderRadiusStyle
                                                    .txtCircleBorder20),
                                        child: Text("Apply",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtZCOOLXiaoWeiRegular20))),
                                Padding(
                                    padding: getPadding(top: 45),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          CustomImageView(
                                              svgPath: ImageConstant.imgPlay,
                                              height: getVerticalSize(18.00),
                                              width: getHorizontalSize(15.00),
                                              margin: getMargin(
                                                  top: 40, bottom: 41),
                                              onTap: () {
                                                onTapImgPlay(context);
                                              }),
                                          CustomImageView(
                                              svgPath: ImageConstant.imgTicket,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 50,
                                                  top: 37,
                                                  bottom: 38),
                                              onTap: () {
                                                onTapImgTicket(context);
                                              }),
                                          Container(
                                              width: getHorizontalSize(57.00),
                                              margin: getMargin(left: 33),
                                              padding: getPadding(
                                                  left: 16,
                                                  top: 27,
                                                  right: 16,
                                                  bottom: 27),
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              19.00)),
                                                  image: DecorationImage(
                                                      image: AssetImage(
                                                          ImageConstant
                                                              .imgGroup38),
                                                      fit: BoxFit.cover)),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgHome,
                                                        height: getSize(24.00),
                                                        width: getSize(24.00),
                                                        onTap: () {
                                                          onTapImgHome(context);
                                                        }),
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Padding(
                                                            padding: getPadding(
                                                                top: 6,
                                                                bottom: 4),
                                                            child: Text("Home",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtZCOOLXiaoWeiRegular10WhiteA700)))
                                                  ])),
                                          CustomImageView(
                                              svgPath: ImageConstant.imgMenu,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 30,
                                                  top: 37,
                                                  bottom: 38),
                                              onTap: () {
                                                onTapImgMenu(context);
                                              }),
                                          CustomImageView(
                                              svgPath:
                                                  ImageConstant.imgBookmark,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 49,
                                                  top: 37,
                                                  bottom: 38),
                                              onTap: () {
                                                onTapImgBookmark(context);
                                              })
                                        ]))
                              ]))),
                  CustomImageView(
                      imagePath: ImageConstant.imgFilter,
                      height: getVerticalSize(57.00),
                      width: getHorizontalSize(56.00),
                      alignment: Alignment.topRight,
                      margin: getMargin(top: 53)),
                  Align(
                      alignment: Alignment.center,
                      child: Padding(
                          padding: getPadding(right: 1),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(left: 8),
                                    child: Text("Location",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtAbhayaLibreExtraBold25Bluegray900)),
                                CustomDropDown(
                                    width: 307,
                                    focusNode: FocusNode(),
                                    icon: Container(
                                        margin: getMargin(left: 30),
                                        child: CustomImageView(
                                            svgPath:
                                                ImageConstant.imgArrowdown)),
                                    hintText: "ALU CAMPUS",
                                    margin: getMargin(top: 13),
                                    alignment: Alignment.center,
                                    items: dropdownItemList,
                                    onChanged: (value) {}),
                                Container(
                                    height: getVerticalSize(3.00),
                                    width: getHorizontalSize(374.00),
                                    margin: getMargin(top: 13),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.blueGray100))
                              ])))
                ]))));
  }

  onTapImgArrowdown(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.startOverlayScreen);
  }

  onTapTxtGroupFive(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormScreen);
  }

  onTapImgPlay(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.profileScreen);
  }

  onTapImgTicket(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormScreen);
  }

  onTapImgHome(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homePageScreen);
  }

  onTapImgMenu(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormOneScreen);
  }

  onTapImgBookmark(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.addEventScreen);
  }
}
