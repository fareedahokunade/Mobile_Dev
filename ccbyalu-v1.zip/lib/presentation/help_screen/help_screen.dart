import 'package:ccbyalu/core/app_export.dart';
import 'package:flutter/material.dart';

class HelpScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: size.height,
                width: size.width,
                child: Stack(alignment: Alignment.topCenter, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          width: size.width,
                          padding: getPadding(
                              left: 12, top: 8, right: 12, bottom: 8),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder35),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(top: 41),
                                    child: Row(children: [
                                      Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            CustomImageView(
                                                svgPath: ImageConstant.imgFrame,
                                                height: getSize(22.00),
                                                width: getSize(22.00),
                                                alignment: Alignment.center),
                                            CustomImageView(
                                                svgPath: ImageConstant
                                                    .imgBookmarkWhiteA700,
                                                height: getVerticalSize(24.00),
                                                width: getHorizontalSize(16.00),
                                                alignment:
                                                    Alignment.centerRight,
                                                margin: getMargin(top: 86)),
                                            Padding(
                                                padding: getPadding(top: 5),
                                                child: Text("FAQs",
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .txtAbhayaLibreExtraBold25Bluegray900))
                                          ]),
                                      Container(
                                          height: getVerticalSize(39.00),
                                          width: getHorizontalSize(167.00),
                                          margin: getMargin(
                                              left: 24, top: 105, bottom: 22),
                                          child: Stack(
                                              alignment: Alignment.topCenter,
                                              children: [
                                                Align(
                                                    alignment:
                                                        Alignment.bottomRight,
                                                    child: Container(
                                                        height: getVerticalSize(
                                                            25.00),
                                                        width:
                                                            getHorizontalSize(
                                                                80.00),
                                                        margin: getMargin(
                                                            right: 33),
                                                        decoration: BoxDecoration(
                                                            color: ColorConstant
                                                                .whiteA700))),
                                                Align(
                                                    alignment:
                                                        Alignment.topCenter,
                                                    child: Text("Burundi Room",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtZCOOLXiaoWeiRegular28WhiteA700))
                                              ]))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 8, top: 34),
                                    child: Text(
                                        "How to login with school email",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtAbhayaLibreExtraBold25Indigo50099)),
                                Container(
                                    height: getVerticalSize(30.00),
                                    width: getHorizontalSize(283.00),
                                    margin: getMargin(left: 8, top: 22),
                                    child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Align(
                                              alignment: Alignment.center,
                                              child: Text(
                                                  "How to solve booking errors",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtAbhayaLibreExtraBold25Indigo50099)),
                                          Align(
                                              alignment: Alignment.center,
                                              child: Text(
                                                  "How to solve booking errors",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtAbhayaLibreExtraBold25Indigo50099))
                                        ])),
                                Padding(
                                    padding: getPadding(left: 7, top: 28),
                                    child: Text(
                                        "What to do if i misplace device",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtAbhayaLibreExtraBold25Indigo50099)),
                                Padding(
                                    padding: getPadding(left: 8, top: 22),
                                    child: Text("How to reset password",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtAbhayaLibreExtraBold25Indigo50099)),
                                Padding(
                                    padding: getPadding(top: 63),
                                    child: Text("CONTACT",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtAbhayaLibreExtraBold25Bluegray900)),
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        width: getHorizontalSize(327.00),
                                        margin: getMargin(top: 22),
                                        child: Text(
                                            " Send an emial help@alueducation.com for further issues",
                                            maxLines: null,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtRobotoRegular16Black900
                                                .copyWith(
                                                    letterSpacing:
                                                        getHorizontalSize(
                                                            0.57))))),
                                Padding(
                                    padding: getPadding(left: 135, top: 48),
                                    child: Text("Upload",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtZCOOLXiaoWeiRegular20)),
                                Align(
                                    alignment: Alignment.center,
                                    child: Padding(
                                        padding: getPadding(top: 37),
                                        child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgPlay,
                                                  height:
                                                      getVerticalSize(18.00),
                                                  width:
                                                      getHorizontalSize(15.00),
                                                  margin: getMargin(
                                                      top: 40, bottom: 41),
                                                  onTap: () {
                                                    onTapImgPlay(context);
                                                  }),
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgTicket,
                                                  height: getSize(24.00),
                                                  width: getSize(24.00),
                                                  margin: getMargin(
                                                      left: 50,
                                                      top: 37,
                                                      bottom: 38),
                                                  onTap: () {
                                                    onTapImgTicket(context);
                                                  }),
                                              Container(
                                                  width:
                                                      getHorizontalSize(57.00),
                                                  margin: getMargin(left: 33),
                                                  padding: getPadding(
                                                      left: 16,
                                                      top: 27,
                                                      right: 16,
                                                      bottom: 27),
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              getHorizontalSize(
                                                                  19.00)),
                                                      image: DecorationImage(
                                                          image: AssetImage(
                                                              ImageConstant
                                                                  .imgGroup38),
                                                          fit: BoxFit.cover)),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        CustomImageView(
                                                            svgPath:
                                                                ImageConstant
                                                                    .imgHome,
                                                            height:
                                                                getSize(24.00),
                                                            width:
                                                                getSize(24.00),
                                                            onTap: () {
                                                              onTapImgHome(
                                                                  context);
                                                            }),
                                                        Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Padding(
                                                                padding:
                                                                    getPadding(
                                                                        top: 6,
                                                                        bottom:
                                                                            4),
                                                                child: Text(
                                                                    "Home",
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtZCOOLXiaoWeiRegular10WhiteA700)))
                                                      ])),
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgMenu,
                                                  height: getSize(24.00),
                                                  width: getSize(24.00),
                                                  margin: getMargin(
                                                      left: 30,
                                                      top: 37,
                                                      bottom: 38),
                                                  onTap: () {
                                                    onTapImgMenu(context);
                                                  }),
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgBookmark,
                                                  height: getSize(24.00),
                                                  width: getSize(24.00),
                                                  margin: getMargin(
                                                      left: 49,
                                                      top: 37,
                                                      bottom: 38),
                                                  onTap: () {
                                                    onTapImgBookmarkOne(
                                                        context);
                                                  })
                                            ])))
                              ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          height: getVerticalSize(157.00),
                          width: size.width,
                          child: Stack(alignment: Alignment.center, children: [
                            CustomImageView(
                                imagePath: ImageConstant.imgEllipse756157x375,
                                height: getVerticalSize(157.00),
                                width: getHorizontalSize(375.00),
                                alignment: Alignment.center),
                            Align(
                                alignment: Alignment.center,
                                child: Text("Help",
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle
                                        .txtZCOOLXiaoWeiRegular28WhiteA700))
                          ])))
                ]))));
  }

  onTapImgPlay(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.profileScreen);
  }

  onTapImgTicket(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormScreen);
  }

  onTapImgHome(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homePageScreen);
  }

  onTapImgMenu(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormOneScreen);
  }

  onTapImgBookmarkOne(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.addEventScreen);
  }
}
