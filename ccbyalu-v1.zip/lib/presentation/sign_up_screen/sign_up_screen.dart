import 'package:ccbyalu/core/app_export.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

class SignUpScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: size.height,
                width: size.width,
                child: Stack(children: [
                  Align(
                      alignment: Alignment.center,
                      child: SingleChildScrollView(
                          child: Container(
                              height: size.height,
                              width: size.width,
                              child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Align(
                                        alignment: Alignment.center,
                                        child: Container(
                                            width: size.width,
                                            padding: getPadding(
                                                left: 11,
                                                top: 49,
                                                right: 11,
                                                bottom: 49),
                                            decoration: AppDecoration
                                                .fillWhiteA700
                                                .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder35),
                                            child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgFrame,
                                                      height: getSize(22.00),
                                                      width: getSize(22.00),
                                                      margin:
                                                          getMargin(left: 19)),
                                                  Container(
                                                      height: getVerticalSize(
                                                          510.00),
                                                      width: getHorizontalSize(
                                                          351.00),
                                                      margin: getMargin(
                                                          left: 2,
                                                          top: 59,
                                                          bottom: 123),
                                                      child: Stack(
                                                          alignment: Alignment
                                                              .topCenter,
                                                          children: [
                                                            Align(
                                                                alignment: Alignment
                                                                    .bottomCenter,
                                                                child:
                                                                    Container(
                                                                        width: getHorizontalSize(
                                                                            351.00),
                                                                        padding: getPadding(
                                                                            top:
                                                                                31,
                                                                            bottom:
                                                                                31),
                                                                        decoration: BoxDecoration(
                                                                            borderRadius: BorderRadius.circular(getHorizontalSize(
                                                                                19.00)),
                                                                            image: DecorationImage(
                                                                                image: fs.Svg(ImageConstant
                                                                                    .imgGroup42),
                                                                                fit: BoxFit
                                                                                    .cover)),
                                                                        child: Column(
                                                                            mainAxisSize:
                                                                                MainAxisSize.min,
                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                            children: [
                                                                              Padding(
                                                                                  padding: getPadding(left: 11),
                                                                                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                                                                    Text("Email", overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtAbhayaLibreExtraBold25),
                                                                                    Container(height: getSize(5.00), width: getSize(5.00), margin: getMargin(left: 101, top: 10, bottom: 14), decoration: BoxDecoration(color: ColorConstant.blueA1007e, borderRadius: BorderRadius.circular(getHorizontalSize(2.00))))
                                                                                  ])),
                                                                              Align(alignment: Alignment.centerRight, child: Container(height: getSize(9.00), width: getSize(9.00), margin: getMargin(top: 15, right: 26), decoration: BoxDecoration(color: ColorConstant.amber30075, borderRadius: BorderRadius.circular(getHorizontalSize(4.00))))),
                                                                              Container(height: getVerticalSize(4.00), width: getHorizontalSize(340.00), margin: getMargin(left: 11, top: 9), decoration: BoxDecoration(color: ColorConstant.blueGray100)),
                                                                              Padding(padding: getPadding(left: 11, top: 22), child: Text("Password", overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtAbhayaLibreExtraBold25)),
                                                                              Container(height: getVerticalSize(4.00), width: getHorizontalSize(340.00), margin: getMargin(left: 11, top: 33, bottom: 55), decoration: BoxDecoration(color: ColorConstant.blueGray100))
                                                                            ]))),
                                                            Align(
                                                                alignment:
                                                                    Alignment
                                                                        .topCenter,
                                                                child: Container(
                                                                    height:
                                                                        getVerticalSize(
                                                                            25.00),
                                                                    width: getHorizontalSize(
                                                                        80.00),
                                                                    margin: getMargin(
                                                                        top:
                                                                            39),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                            color:
                                                                                ColorConstant.whiteA700))),
                                                            Align(
                                                                alignment:
                                                                    Alignment
                                                                        .topLeft,
                                                                child: Padding(
                                                                    padding: getPadding(
                                                                        left:
                                                                            62,
                                                                        top:
                                                                            207),
                                                                    child: Text(
                                                                        "🥦",
                                                                        overflow:
                                                                            TextOverflow
                                                                                .ellipsis,
                                                                        textAlign:
                                                                            TextAlign
                                                                                .left,
                                                                        style: AppStyle
                                                                            .txtRobotoRegular24
                                                                            .copyWith(letterSpacing: getHorizontalSize(0.14))))),
                                                            Align(
                                                                alignment:
                                                                    Alignment
                                                                        .topCenter,
                                                                child: Container(
                                                                    height: getVerticalSize(
                                                                        232.00),
                                                                    width: getHorizontalSize(
                                                                        327.00),
                                                                    decoration: BoxDecoration(
                                                                        color: ColorConstant
                                                                            .gray5003f,
                                                                        borderRadius:
                                                                            BorderRadius.circular(getHorizontalSize(32.00)))))
                                                          ]))
                                                ]))),
                                    Align(
                                        alignment: Alignment.bottomCenter,
                                        child: Container(
                                            height: getVerticalSize(571.00),
                                            width: size.width,
                                            child: Stack(
                                                alignment: Alignment.topCenter,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgEllipse7564,
                                                      height: getVerticalSize(
                                                          571.00),
                                                      width: getHorizontalSize(
                                                          375.00),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment:
                                                          Alignment.topCenter,
                                                      child: GestureDetector(
                                                          onTap: () {
                                                            onTapTxtSignIn(
                                                                context);
                                                          },
                                                          child: Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 42),
                                                              child: Text(
                                                                  "Sign In",
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtZCOOLXiaoWeiRegular18))))
                                                ]))),
                                    Align(
                                        alignment: Alignment.topCenter,
                                        child: Container(
                                            height: getVerticalSize(397.00),
                                            width: size.width,
                                            child: Stack(
                                                alignment: Alignment.bottomLeft,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgGraphic,
                                                      height: getVerticalSize(
                                                          397.00),
                                                      width: getHorizontalSize(
                                                          375.00),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment:
                                                          Alignment.bottomLeft,
                                                      child: Padding(
                                                          padding: getPadding(
                                                              left: 34,
                                                              bottom: 10),
                                                          child: Row(children: [
                                                            Container(
                                                                height:
                                                                    getVerticalSize(
                                                                        46.00),
                                                                width:
                                                                    getHorizontalSize(
                                                                        70.00),
                                                                child: Stack(
                                                                    alignment:
                                                                        Alignment
                                                                            .topLeft,
                                                                    children: [
                                                                      Align(
                                                                          alignment:
                                                                              Alignment.bottomCenter,
                                                                          child: Container(
                                                                              height: getVerticalSize(14.00),
                                                                              width: getHorizontalSize(70.00),
                                                                              child: Stack(alignment: Alignment.centerLeft, children: [
                                                                                CustomImageView(imagePath: ImageConstant.imgShadow, height: getVerticalSize(14.00), width: getHorizontalSize(70.00), alignment: Alignment.center),
                                                                                CustomImageView(imagePath: ImageConstant.imgShadow14x37, height: getVerticalSize(14.00), width: getHorizontalSize(37.00), alignment: Alignment.centerLeft)
                                                                              ]))),
                                                                      Align(
                                                                          alignment:
                                                                              Alignment.topLeft,
                                                                          child: Container(
                                                                              height: getVerticalSize(42.00),
                                                                              width: getHorizontalSize(30.00),
                                                                              margin: getMargin(left: 2),
                                                                              child: Stack(alignment: Alignment.center, children: [
                                                                                CustomImageView(imagePath: ImageConstant.imgBase, height: getVerticalSize(42.00), width: getHorizontalSize(30.00), alignment: Alignment.center),
                                                                                Align(
                                                                                    alignment: Alignment.center,
                                                                                    child: Container(
                                                                                        height: getVerticalSize(42.00),
                                                                                        width: getHorizontalSize(30.00),
                                                                                        child: Stack(alignment: Alignment.center, children: [
                                                                                          CustomImageView(imagePath: ImageConstant.imgBase, height: getVerticalSize(42.00), width: getHorizontalSize(30.00), alignment: Alignment.center),
                                                                                          Align(
                                                                                              alignment: Alignment.center,
                                                                                              child: Container(
                                                                                                  height: getVerticalSize(42.00),
                                                                                                  width: getHorizontalSize(30.00),
                                                                                                  child: Stack(alignment: Alignment.topCenter, children: [
                                                                                                    Align(
                                                                                                        alignment: Alignment.bottomRight,
                                                                                                        child: Container(
                                                                                                            width: getHorizontalSize(18.00),
                                                                                                            margin: getMargin(right: 3, bottom: 5),
                                                                                                            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.start, children: [
                                                                                                              Container(
                                                                                                                  height: getVerticalSize(10.00),
                                                                                                                  width: getHorizontalSize(17.00),
                                                                                                                  child: Stack(alignment: Alignment.center, children: [
                                                                                                                    CustomImageView(imagePath: ImageConstant.imgImage, height: getVerticalSize(10.00), width: getHorizontalSize(17.00), alignment: Alignment.center),
                                                                                                                    Align(
                                                                                                                        alignment: Alignment.center,
                                                                                                                        child: Container(
                                                                                                                            height: getVerticalSize(10.00),
                                                                                                                            width: getHorizontalSize(17.00),
                                                                                                                            child: Stack(alignment: Alignment.centerRight, children: [
                                                                                                                              CustomImageView(imagePath: ImageConstant.imgImage, height: getVerticalSize(10.00), width: getHorizontalSize(17.00), alignment: Alignment.center),
                                                                                                                              Align(
                                                                                                                                  alignment: Alignment.centerRight,
                                                                                                                                  child: Container(
                                                                                                                                      height: getVerticalSize(7.00),
                                                                                                                                      width: getHorizontalSize(10.00),
                                                                                                                                      margin: getMargin(right: 3),
                                                                                                                                      child: Stack(alignment: Alignment.center, children: [
                                                                                                                                        CustomImageView(imagePath: ImageConstant.imgMoumtain, height: getVerticalSize(7.00), width: getHorizontalSize(10.00), alignment: Alignment.center),
                                                                                                                                        CustomImageView(imagePath: ImageConstant.imgMoumtain, height: getVerticalSize(7.00), width: getHorizontalSize(10.00), alignment: Alignment.center)
                                                                                                                                      ])))
                                                                                                                            ])))
                                                                                                                  ])),
                                                                                                              Align(
                                                                                                                  alignment: Alignment.centerRight,
                                                                                                                  child: Container(
                                                                                                                      height: getVerticalSize(15.00),
                                                                                                                      width: getHorizontalSize(16.00),
                                                                                                                      margin: getMargin(top: 1),
                                                                                                                      child: Stack(alignment: Alignment.center, children: [
                                                                                                                        CustomImageView(imagePath: ImageConstant.imgCircles, height: getVerticalSize(15.00), width: getHorizontalSize(16.00), alignment: Alignment.center),
                                                                                                                        CustomImageView(imagePath: ImageConstant.imgCircles, height: getVerticalSize(15.00), width: getHorizontalSize(16.00), alignment: Alignment.center)
                                                                                                                      ])))
                                                                                                            ]))),
                                                                                                    Align(
                                                                                                        alignment: Alignment.topCenter,
                                                                                                        child: Container(
                                                                                                            height: getVerticalSize(7.00),
                                                                                                            width: getHorizontalSize(20.00),
                                                                                                            child: Stack(alignment: Alignment.center, children: [
                                                                                                              CustomImageView(imagePath: ImageConstant.img2, height: getVerticalSize(7.00), width: getHorizontalSize(20.00), alignment: Alignment.center),
                                                                                                              CustomImageView(imagePath: ImageConstant.img2, height: getVerticalSize(7.00), width: getHorizontalSize(20.00), alignment: Alignment.center)
                                                                                                            ]))),
                                                                                                    Align(
                                                                                                        alignment: Alignment.center,
                                                                                                        child: Container(
                                                                                                            height: getVerticalSize(42.00),
                                                                                                            width: getHorizontalSize(30.00),
                                                                                                            child: Stack(alignment: Alignment.center, children: [
                                                                                                              CustomImageView(imagePath: ImageConstant.imgSpecular, height: getVerticalSize(42.00), width: getHorizontalSize(30.00), alignment: Alignment.center),
                                                                                                              Align(
                                                                                                                  alignment: Alignment.center,
                                                                                                                  child: Container(
                                                                                                                      height: getVerticalSize(42.00),
                                                                                                                      width: getHorizontalSize(30.00),
                                                                                                                      child: Stack(alignment: Alignment.center, children: [
                                                                                                                        CustomImageView(imagePath: ImageConstant.imgSpecular, height: getVerticalSize(42.00), width: getHorizontalSize(30.00), alignment: Alignment.center),
                                                                                                                        CustomImageView(imagePath: ImageConstant.imgSpecular, height: getVerticalSize(42.00), width: getHorizontalSize(30.00), alignment: Alignment.center)
                                                                                                                      ])))
                                                                                                            ])))
                                                                                                  ])))
                                                                                        ])))
                                                                              ])))
                                                                    ])),
                                                            Container(
                                                                height: getSize(
                                                                    5.00),
                                                                width: getSize(
                                                                    5.00),
                                                                margin:
                                                                    getMargin(
                                                                        left:
                                                                            17,
                                                                        top: 28,
                                                                        bottom:
                                                                            13),
                                                                decoration: BoxDecoration(
                                                                    color: ColorConstant
                                                                        .amber30075,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            getHorizontalSize(2.00))))
                                                          ])))
                                                ]))),
                                    Align(
                                        alignment: Alignment.bottomLeft,
                                        child: Container(
                                            height: getVerticalSize(45.00),
                                            width: getHorizontalSize(94.00),
                                            margin: getMargin(bottom: 109),
                                            child: Stack(
                                                alignment: Alignment.topRight,
                                                children: [
                                                  Align(
                                                      alignment: Alignment
                                                          .bottomCenter,
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  21.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  94.00),
                                                          child: Stack(
                                                              alignment: Alignment
                                                                  .centerRight,
                                                              children: [
                                                                CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgShadow21x94,
                                                                    height:
                                                                        getVerticalSize(
                                                                            21.00),
                                                                    width: getHorizontalSize(
                                                                        94.00),
                                                                    alignment:
                                                                        Alignment
                                                                            .center),
                                                                CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgShadow1,
                                                                    height:
                                                                        getVerticalSize(
                                                                            21.00),
                                                                    width: getHorizontalSize(
                                                                        46.00),
                                                                    alignment:
                                                                        Alignment
                                                                            .centerRight,
                                                                    margin: getMargin(
                                                                        right:
                                                                            18))
                                                              ]))),
                                                  Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  30.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  26.00),
                                                          margin: getMargin(
                                                              right: 28),
                                                          child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgBase30x26,
                                                                    height:
                                                                        getVerticalSize(
                                                                            30.00),
                                                                    width: getHorizontalSize(
                                                                        26.00),
                                                                    alignment:
                                                                        Alignment
                                                                            .center),
                                                                Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child: Container(
                                                                        height: getVerticalSize(30.00),
                                                                        width: getHorizontalSize(26.00),
                                                                        child: Stack(alignment: Alignment.center, children: [
                                                                          CustomImageView(
                                                                              imagePath: ImageConstant.imgBase30x26,
                                                                              height: getVerticalSize(30.00),
                                                                              width: getHorizontalSize(26.00),
                                                                              alignment: Alignment.center),
                                                                          Align(
                                                                              alignment: Alignment.center,
                                                                              child: Container(
                                                                                  height: getVerticalSize(30.00),
                                                                                  width: getHorizontalSize(26.00),
                                                                                  child: Stack(alignment: Alignment.topCenter, children: [
                                                                                    Align(
                                                                                        alignment: Alignment.topRight,
                                                                                        child: Container(
                                                                                            height: getSize(3.00),
                                                                                            width: getSize(3.00),
                                                                                            margin: getMargin(top: 12, right: 9),
                                                                                            child: Stack(alignment: Alignment.center, children: [
                                                                                              CustomImageView(imagePath: ImageConstant.img1, height: getSize(3.00), width: getSize(3.00), alignment: Alignment.center),
                                                                                              CustomImageView(imagePath: ImageConstant.img1, height: getSize(3.00), width: getSize(3.00), alignment: Alignment.center)
                                                                                            ]))),
                                                                                    Align(
                                                                                        alignment: Alignment.topCenter,
                                                                                        child: Container(
                                                                                            height: getVerticalSize(6.00),
                                                                                            width: getHorizontalSize(3.00),
                                                                                            margin: getMargin(top: 6),
                                                                                            child: Stack(alignment: Alignment.center, children: [
                                                                                              CustomImageView(imagePath: ImageConstant.imgMin, height: getVerticalSize(6.00), width: getHorizontalSize(3.00), alignment: Alignment.center),
                                                                                              CustomImageView(imagePath: ImageConstant.imgMin, height: getVerticalSize(6.00), width: getHorizontalSize(3.00), alignment: Alignment.center)
                                                                                            ]))),
                                                                                    Align(
                                                                                        alignment: Alignment.topRight,
                                                                                        child: Container(
                                                                                            height: getVerticalSize(3.00),
                                                                                            width: getHorizontalSize(4.00),
                                                                                            margin: getMargin(top: 10, right: 6),
                                                                                            child: Stack(alignment: Alignment.center, children: [
                                                                                              CustomImageView(imagePath: ImageConstant.imgHr, height: getVerticalSize(3.00), width: getHorizontalSize(4.00), alignment: Alignment.center),
                                                                                              CustomImageView(imagePath: ImageConstant.imgHr, height: getVerticalSize(3.00), width: getHorizontalSize(4.00), alignment: Alignment.center)
                                                                                            ]))),
                                                                                    Align(
                                                                                        alignment: Alignment.center,
                                                                                        child: Container(
                                                                                            height: getVerticalSize(30.00),
                                                                                            width: getHorizontalSize(26.00),
                                                                                            child: Stack(alignment: Alignment.center, children: [
                                                                                              CustomImageView(imagePath: ImageConstant.imgSpecular30x26, height: getVerticalSize(30.00), width: getHorizontalSize(26.00), alignment: Alignment.center),
                                                                                              Align(
                                                                                                  alignment: Alignment.center,
                                                                                                  child: Container(
                                                                                                      height: getVerticalSize(30.00),
                                                                                                      width: getHorizontalSize(26.00),
                                                                                                      child: Stack(alignment: Alignment.center, children: [
                                                                                                        CustomImageView(imagePath: ImageConstant.imgSpecular30x26, height: getVerticalSize(30.00), width: getHorizontalSize(26.00), alignment: Alignment.center),
                                                                                                        CustomImageView(imagePath: ImageConstant.imgSpecular30x26, height: getVerticalSize(30.00), width: getHorizontalSize(26.00), alignment: Alignment.center)
                                                                                                      ])))
                                                                                            ])))
                                                                                  ])))
                                                                        ])))
                                                              ])))
                                                ]))),
                                    Align(
                                        alignment: Alignment.bottomRight,
                                        child: Container(
                                            height: getVerticalSize(59.00),
                                            width: getHorizontalSize(38.00),
                                            margin: getMargin(bottom: 155),
                                            child: Stack(
                                                alignment: Alignment.center,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgCube59x38,
                                                      height: getVerticalSize(
                                                          59.00),
                                                      width: getHorizontalSize(
                                                          38.00),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  59.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  38.00),
                                                          child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgCube59x38,
                                                                    height:
                                                                        getVerticalSize(
                                                                            59.00),
                                                                    width: getHorizontalSize(
                                                                        38.00),
                                                                    alignment:
                                                                        Alignment
                                                                            .center),
                                                                Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child: Container(
                                                                        height: getVerticalSize(59.00),
                                                                        width: getHorizontalSize(38.00),
                                                                        child: Stack(alignment: Alignment.center, children: [
                                                                          CustomImageView(
                                                                              imagePath: ImageConstant.imgSpecular59x38,
                                                                              height: getVerticalSize(59.00),
                                                                              width: getHorizontalSize(38.00),
                                                                              alignment: Alignment.center),
                                                                          Align(
                                                                              alignment: Alignment.center,
                                                                              child: Container(
                                                                                  height: getVerticalSize(59.00),
                                                                                  width: getHorizontalSize(38.00),
                                                                                  child: Stack(alignment: Alignment.center, children: [
                                                                                    CustomImageView(imagePath: ImageConstant.imgSpecular59x38, height: getVerticalSize(59.00), width: getHorizontalSize(38.00), alignment: Alignment.center),
                                                                                    CustomImageView(imagePath: ImageConstant.imgSpecular59x38, height: getVerticalSize(59.00), width: getHorizontalSize(38.00), alignment: Alignment.center)
                                                                                  ])))
                                                                        ])))
                                                              ])))
                                                ]))),
                                    Align(
                                        alignment: Alignment.bottomCenter,
                                        child: Padding(
                                            padding: getPadding(
                                                left: 24,
                                                right: 11,
                                                bottom: 169),
                                            child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Text("Confirm Password",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtAbhayaLibreExtraBold25),
                                                  Container(
                                                      height:
                                                          getVerticalSize(4.00),
                                                      width: getHorizontalSize(
                                                          340.00),
                                                      margin:
                                                          getMargin(top: 33),
                                                      decoration: BoxDecoration(
                                                          color: ColorConstant
                                                              .blueGray100))
                                                ])))
                                  ]))))
                ]))));
  }

  onTapTxtSignIn(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homePageScreen);
  }
}
