import 'package:ccbyalu/core/app_export.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_image.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_subtitle_1.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_subtitle_2.dart';
import 'package:ccbyalu/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class HomePageScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: size.height,
                width: size.width,
                child: Stack(alignment: Alignment.topCenter, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          width: size.width,
                          padding: getPadding(
                              left: 30, top: 8, right: 30, bottom: 8),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder35),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Spacer(),
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        height: getVerticalSize(25.00),
                                        width: getHorizontalSize(80.00),
                                        decoration: BoxDecoration(
                                            color: ColorConstant.whiteA700))),
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        width: getHorizontalSize(187.00),
                                        margin: getMargin(top: 27),
                                        child: Text("Book a pod with ease",
                                            maxLines: null,
                                            textAlign: TextAlign.center,
                                            style: AppStyle
                                                .txtZCOOLXiaoWeiRegular28))),
                                Padding(
                                    padding:
                                        getPadding(left: 2, top: 37, right: 17),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                              padding: getPadding(
                                                  left: 23,
                                                  top: 10,
                                                  right: 23,
                                                  bottom: 10),
                                              decoration: AppDecoration
                                                  .fillBlue50
                                                  .copyWith(
                                                      borderRadius:
                                                          BorderRadiusStyle
                                                              .roundedBorder17),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Card(
                                                        clipBehavior:
                                                            Clip.antiAlias,
                                                        elevation: 0,
                                                        margin:
                                                            EdgeInsets.all(0),
                                                        color: ColorConstant
                                                            .whiteA700,
                                                        shape: RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        24.00))),
                                                        child: Container(
                                                            height:
                                                                getSize(48.00),
                                                            width:
                                                                getSize(48.00),
                                                            padding: getPadding(
                                                                left: 3,
                                                                top: 8,
                                                                right: 3,
                                                                bottom: 8),
                                                            decoration: AppDecoration
                                                                .fillWhiteA700
                                                                .copyWith(
                                                                    borderRadius:
                                                                        BorderRadiusStyle
                                                                            .circleBorder24),
                                                            child: Stack(
                                                                alignment:
                                                                    Alignment
                                                                        .topCenter,
                                                                children: [
                                                                  Align(
                                                                      alignment:
                                                                          Alignment
                                                                              .bottomRight,
                                                                      child: Container(
                                                                          margin: getMargin(
                                                                              bottom:
                                                                                  1),
                                                                          decoration: AppDecoration
                                                                              .txtOutlineBlack90047,
                                                                          child: Text(
                                                                              "🚙",
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtRobotoRegular18))),
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgIcons8door481,
                                                                      height: getSize(
                                                                          28.00),
                                                                      width: getSize(
                                                                          28.00),
                                                                      alignment:
                                                                          Alignment
                                                                              .topCenter),
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgIcons8creditcard48,
                                                                      height: getSize(
                                                                          18.00),
                                                                      width: getSize(
                                                                          18.00),
                                                                      alignment:
                                                                          Alignment
                                                                              .bottomLeft,
                                                                      margin: getMargin(
                                                                          left:
                                                                              6))
                                                                ]))),
                                                    Padding(
                                                        padding: getPadding(
                                                            top: 12, bottom: 4),
                                                        child: Text("Book Room",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular10))
                                                  ])),
                                          Container(
                                              padding: getPadding(
                                                  left: 23,
                                                  top: 11,
                                                  right: 23,
                                                  bottom: 11),
                                              decoration: AppDecoration
                                                  .fillDeeporange50
                                                  .copyWith(
                                                      borderRadius:
                                                          BorderRadiusStyle
                                                              .roundedBorder17),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Card(
                                                        clipBehavior:
                                                            Clip.antiAlias,
                                                        elevation: 0,
                                                        margin:
                                                            EdgeInsets.all(0),
                                                        color: ColorConstant
                                                            .whiteA700,
                                                        shape: RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        24.00))),
                                                        child: Container(
                                                            height:
                                                                getSize(48.00),
                                                            width:
                                                                getSize(48.00),
                                                            padding: getPadding(
                                                                left: 2,
                                                                top: 3,
                                                                right: 2,
                                                                bottom: 3),
                                                            decoration: AppDecoration
                                                                .fillWhiteA700
                                                                .copyWith(
                                                                    borderRadius:
                                                                        BorderRadiusStyle
                                                                            .circleBorder24),
                                                            child: Stack(
                                                                alignment:
                                                                    Alignment
                                                                        .topCenter,
                                                                children: [
                                                                  Align(
                                                                      alignment:
                                                                          Alignment
                                                                              .topRight,
                                                                      child: Container(
                                                                          margin: getMargin(
                                                                              top:
                                                                                  2),
                                                                          decoration: AppDecoration
                                                                              .txtOutlineBlack90047,
                                                                          child: Text(
                                                                              "🚙",
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtRobotoRegular22))),
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgIcons8tearoffcalendar48,
                                                                      height: getSize(
                                                                          34.00),
                                                                      width: getSize(
                                                                          34.00),
                                                                      alignment:
                                                                          Alignment
                                                                              .topCenter)
                                                                ]))),
                                                    Padding(
                                                        padding: getPadding(
                                                            top: 11, bottom: 3),
                                                        child: Text("Add Event",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular10))
                                                  ]))
                                        ])),
                                Padding(
                                    padding: getPadding(top: 71, right: 107),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Padding(
                                              padding:
                                                  getPadding(top: 6, bottom: 6),
                                              child: Text("Events ",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtZCOOLXiaoWeiRegular17)),
                                          Container(
                                              height: getSize(30.00),
                                              width: getSize(30.00),
                                              child: Stack(
                                                  alignment:
                                                      Alignment.bottomLeft,
                                                  children: [
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Container(
                                                            padding: getPadding(
                                                                left: 2,
                                                                right: 2),
                                                            decoration: AppDecoration
                                                                .fillGray50
                                                                .copyWith(
                                                                    borderRadius:
                                                                        BorderRadiusStyle
                                                                            .roundedBorder17),
                                                            child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .end,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                children: [
                                                                  Container(
                                                                      height: getSize(
                                                                          22.00),
                                                                      width: getSize(
                                                                          22.00),
                                                                      margin: getMargin(
                                                                          top:
                                                                              7),
                                                                      decoration: BoxDecoration(
                                                                          color: ColorConstant
                                                                              .green30075,
                                                                          borderRadius:
                                                                              BorderRadius.circular(getHorizontalSize(11.00))))
                                                                ]))),
                                                    Align(
                                                        alignment: Alignment
                                                            .bottomLeft,
                                                        child: Padding(
                                                            padding: getPadding(
                                                                left: 5,
                                                                bottom: 4),
                                                            child: Text("😋",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtRobotoRegular16
                                                                    .copyWith(
                                                                        letterSpacing:
                                                                            getHorizontalSize(0.57)))))
                                                  ]))
                                        ])),
                                Padding(
                                    padding: getPadding(left: 10, top: 32),
                                    child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Card(
                                              clipBehavior: Clip.antiAlias,
                                              elevation: 0,
                                              margin: EdgeInsets.all(0),
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              24.00))),
                                              child: Container(
                                                  height: getSize(96.00),
                                                  width: getSize(96.00),
                                                  decoration: AppDecoration
                                                      .gradientRed50Red100
                                                      .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .circleBorder24),
                                                  child: Stack(children: [
                                                    CustomImageView(
                                                        imagePath: ImageConstant
                                                            .imgKisspngchinab,
                                                        height: getSize(96.00),
                                                        width: getSize(96.00),
                                                        radius: BorderRadius
                                                            .circular(
                                                                getHorizontalSize(
                                                                    24.00)),
                                                        alignment:
                                                            Alignment.center)
                                                  ]))),
                                          Container(
                                              margin: getMargin(
                                                  left: 24, top: 3, bottom: 7),
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              24.00))),
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Text("Fireside Chat",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtZCOOLXiaoWeiRegular18Gray90001),
                                                    Padding(
                                                        padding:
                                                            getPadding(top: 30),
                                                        child: Row(children: [
                                                          CustomImageView(
                                                              svgPath:
                                                                  ImageConstant
                                                                      .imgLocation,
                                                              height: getSize(
                                                                  16.00),
                                                              width: getSize(
                                                                  16.00),
                                                              radius: BorderRadius
                                                                  .circular(
                                                                      getHorizontalSize(
                                                                          8.00))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      left: 8,
                                                                      top: 3),
                                                              child: Text(
                                                                  "Burundi Room, ALU ",
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtZCOOLXiaoWeiRegular13))
                                                        ])),
                                                    Padding(
                                                        padding: getPadding(
                                                            left: 24, top: 4),
                                                        child: Text(
                                                            "12:30 - 1:30",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular16))
                                                  ]))
                                        ])),
                                Padding(
                                    padding: getPadding(left: 7, top: 53),
                                    child: Row(children: [
                                      CustomImageView(
                                          svgPath: ImageConstant.imgPlay,
                                          height: getVerticalSize(18.00),
                                          width: getHorizontalSize(15.00),
                                          margin:
                                              getMargin(top: 40, bottom: 41),
                                          onTap: () {
                                            onTapImgPlay(context);
                                          }),
                                      CustomImageView(
                                          svgPath: ImageConstant.imgTicket,
                                          height: getSize(24.00),
                                          width: getSize(24.00),
                                          margin: getMargin(
                                              left: 50, top: 37, bottom: 38),
                                          onTap: () {
                                            onTapImgTicket(context);
                                          }),
                                      Container(
                                          width: getHorizontalSize(57.00),
                                          margin: getMargin(left: 33),
                                          padding: getPadding(
                                              left: 16,
                                              top: 27,
                                              right: 16,
                                              bottom: 27),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      getHorizontalSize(19.00)),
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      ImageConstant.imgGroup38),
                                                  fit: BoxFit.cover)),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                CustomImageView(
                                                    svgPath:
                                                        ImageConstant.imgHome,
                                                    height: getSize(24.00),
                                                    width: getSize(24.00)),
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            top: 6, bottom: 4),
                                                        child: Text("Home",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular10WhiteA700)))
                                              ])),
                                      CustomImageView(
                                          svgPath: ImageConstant.imgMenu,
                                          height: getSize(24.00),
                                          width: getSize(24.00),
                                          margin: getMargin(
                                              left: 30, top: 37, bottom: 38),
                                          onTap: () {
                                            onTapImgMenu(context);
                                          }),
                                      CustomImageView(
                                          svgPath: ImageConstant.imgBookmark,
                                          height: getSize(24.00),
                                          width: getSize(24.00),
                                          margin: getMargin(
                                              left: 49, top: 37, bottom: 38),
                                          onTap: () {
                                            onTapImgBookmark(context);
                                          })
                                    ]))
                              ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          height: getVerticalSize(157.00),
                          width: size.width,
                          child:
                              Stack(alignment: Alignment.topCenter, children: [
                            CustomImageView(
                                imagePath: ImageConstant.imgEllipse756,
                                height: getVerticalSize(157.00),
                                width: getHorizontalSize(375.00),
                                alignment: Alignment.center),
                            CustomAppBar(
                                height: getVerticalSize(38.00),
                                leadingWidth: 52,
                                leading: AppbarImage(
                                    height: getSize(22.00),
                                    width: getSize(22.00),
                                    svgPath: ImageConstant.imgFrame,
                                    margin: getMargin(left: 30, bottom: 16)),
                                centerTitle: true,
                                title: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      AppbarSubtitle2(
                                          text: "Welcome",
                                          margin: getMargin(left: 3, right: 3)),
                                      AppbarSubtitle1(
                                          text: "Aimar M.",
                                          margin: getMargin(top: 3))
                                    ]),
                                actions: [
                                  AppbarImage(
                                      height: getSize(22.00),
                                      width: getSize(22.00),
                                      svgPath: ImageConstant.imgLightbulb,
                                      margin: getMargin(
                                          left: 28, right: 28, bottom: 16),
                                      onTap: () => onTapLightbulb(context))
                                ])
                          ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Card(
                          clipBehavior: Clip.antiAlias,
                          elevation: 0,
                          margin: getMargin(top: 109),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(
                                  getHorizontalSize(39.00))),
                          child: Container(
                              height: getSize(78.00),
                              width: getSize(78.00),
                              decoration: AppDecoration
                                  .gradientCyanA200Deeporange400
                                  .copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.circleBorder39),
                              child:
                                  Stack(alignment: Alignment.center, children: [
                                CustomImageView(
                                    imagePath:
                                        ImageConstant.imgToyfacestansparentbg49,
                                    height: getVerticalSize(66.00),
                                    width: getHorizontalSize(54.00),
                                    radius: BorderRadius.circular(
                                        getHorizontalSize(39.00)),
                                    alignment: Alignment.bottomCenter),
                                CustomImageView(
                                    imagePath: ImageConstant.imgJournalism1,
                                    height: getVerticalSize(76.00),
                                    width: getHorizontalSize(78.00),
                                    radius: BorderRadius.circular(
                                        getHorizontalSize(39.00)),
                                    alignment: Alignment.center)
                              ])))),
                  CustomImageView(
                      svgPath: ImageConstant.imgIconsboldmedal,
                      height: getSize(28.00),
                      width: getSize(28.00),
                      alignment: Alignment.topCenter,
                      margin: getMargin(top: 177))
                ]))));
  }

  onTapImgPlay(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.profileScreen);
  }

  onTapImgTicket(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormScreen);
  }

  onTapImgMenu(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormOneScreen);
  }

  onTapImgBookmark(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.addEventScreen);
  }

  onTapLightbulb(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.notificationsScreen);
  }
}
