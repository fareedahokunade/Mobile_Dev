import 'package:ccbyalu/core/app_export.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_image.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_subtitle.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_title.dart';
import 'package:ccbyalu/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: size.height,
                width: size.width,
                child: Stack(alignment: Alignment.bottomCenter, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          width: size.width,
                          padding: getPadding(top: 8, bottom: 8),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder35),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomAppBar(
                                    height: getVerticalSize(52.00),
                                    centerTitle: true,
                                    title: Container(
                                        height: getVerticalSize(52.36),
                                        width: size.width,
                                        child: Stack(
                                            alignment: Alignment.topLeft,
                                            children: [
                                              AppbarImage(
                                                  height: getSize(22.00),
                                                  width: getSize(22.00),
                                                  svgPath:
                                                      ImageConstant.imgFrame,
                                                  margin: getMargin(
                                                      left: 30,
                                                      top: 29,
                                                      right: 323,
                                                      bottom: 1)),
                                              AppbarSubtitle(
                                                  text: "Profile",
                                                  margin: getMargin(
                                                      left: 130,
                                                      top: 5,
                                                      right: 166,
                                                      bottom: 17)),
                                              Align(
                                                  alignment:
                                                      Alignment.bottomCenter,
                                                  child: Container(
                                                      height:
                                                          getVerticalSize(3.00),
                                                      width: size.width,
                                                      margin:
                                                          getMargin(top: 49),
                                                      decoration: BoxDecoration(
                                                          color: ColorConstant
                                                              .blueGray100))),
                                              AppbarTitle(
                                                  text: "x",
                                                  margin: getMargin(
                                                      left: 14,
                                                      right: 344,
                                                      bottom: 17))
                                            ])),
                                    styleType: Style.bgFillBluegray100),
                                Container(
                                    height: getVerticalSize(25.00),
                                    width: getHorizontalSize(80.00),
                                    margin: getMargin(top: 97),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.whiteA700)),
                                Container(
                                    height: getVerticalSize(93.00),
                                    width: size.width,
                                    margin: getMargin(top: 140),
                                    child: Stack(
                                        alignment: Alignment.bottomCenter,
                                        children: [
                                          CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgGroup38,
                                              height: getVerticalSize(59.00),
                                              width: getHorizontalSize(57.00),
                                              radius: BorderRadius.circular(
                                                  getHorizontalSize(19.00)),
                                              alignment: Alignment.topLeft,
                                              margin: getMargin(left: 13)),
                                          Align(
                                              alignment: Alignment.bottomCenter,
                                              child: Container(
                                                  width: size.width,
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        GestureDetector(
                                                            onTap: () {
                                                              onTapTxtMyBookings(
                                                                  context);
                                                            },
                                                            child: Padding(
                                                                padding: getPadding(
                                                                    left: 102),
                                                                child: Text(
                                                                    "My Bookings",
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtAbhayaLibreExtraBold25Bluegray900))),
                                                        Container(
                                                            height:
                                                                getVerticalSize(
                                                                    21.00),
                                                            width: size.width,
                                                            margin: getMargin(
                                                                top: 21),
                                                            decoration: BoxDecoration(
                                                                color: ColorConstant
                                                                    .blueGray100))
                                                      ]))),
                                          CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgIconassignment,
                                              height: getVerticalSize(36.00),
                                              width: getHorizontalSize(37.00),
                                              alignment: Alignment.topLeft,
                                              margin:
                                                  getMargin(left: 23, top: 12))
                                        ])),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                        padding: getPadding(left: 16, top: 13),
                                        child: Row(children: [
                                          Card(
                                              clipBehavior: Clip.antiAlias,
                                              elevation: 0,
                                              margin: EdgeInsets.all(0),
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              19.00))),
                                              child: Container(
                                                  height:
                                                      getVerticalSize(59.00),
                                                  width:
                                                      getHorizontalSize(57.00),
                                                  padding: getPadding(all: 12),
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              getHorizontalSize(
                                                                  19.00)),
                                                      image: DecorationImage(
                                                          image: AssetImage(
                                                              ImageConstant
                                                                  .imgGroup38),
                                                          fit: BoxFit.cover)),
                                                  child: Stack(children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgAirplane,
                                                        height: getSize(32.00),
                                                        width: getSize(32.00),
                                                        alignment:
                                                            Alignment.topCenter)
                                                  ]))),
                                          GestureDetector(
                                              onTap: () {
                                                onTapTxtHelp(context);
                                              },
                                              child: Padding(
                                                  padding: getPadding(
                                                      left: 29,
                                                      top: 17,
                                                      bottom: 11),
                                                  child: Text("Help",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtAbhayaLibreExtraBold25Bluegray900)))
                                        ]))),
                                Spacer(),
                                Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CustomImageView(
                                          svgPath: ImageConstant.imgPlay,
                                          height: getVerticalSize(18.00),
                                          width: getHorizontalSize(15.00),
                                          margin:
                                              getMargin(top: 40, bottom: 41)),
                                      CustomImageView(
                                          svgPath: ImageConstant.imgTicket,
                                          height: getSize(24.00),
                                          width: getSize(24.00),
                                          margin: getMargin(
                                              left: 50, top: 37, bottom: 38),
                                          onTap: () {
                                            onTapImgTicket(context);
                                          }),
                                      Container(
                                          width: getHorizontalSize(57.00),
                                          margin: getMargin(left: 33),
                                          padding: getPadding(
                                              left: 16,
                                              top: 27,
                                              right: 16,
                                              bottom: 27),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      getHorizontalSize(19.00)),
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      ImageConstant.imgGroup38),
                                                  fit: BoxFit.cover)),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                CustomImageView(
                                                    svgPath:
                                                        ImageConstant.imgHome,
                                                    height: getSize(24.00),
                                                    width: getSize(24.00)),
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: getPadding(
                                                            top: 6, bottom: 4),
                                                        child: Text("Home",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular10WhiteA700)))
                                              ])),
                                      CustomImageView(
                                          svgPath: ImageConstant.imgMenu,
                                          height: getSize(24.00),
                                          width: getSize(24.00),
                                          margin: getMargin(
                                              left: 30, top: 37, bottom: 38),
                                          onTap: () {
                                            onTapImgMenu(context);
                                          }),
                                      CustomImageView(
                                          svgPath: ImageConstant.imgBookmark,
                                          height: getSize(24.00),
                                          width: getSize(24.00),
                                          margin: getMargin(
                                              left: 49, top: 37, bottom: 38),
                                          onTap: () {
                                            onTapImgBookmark(context);
                                          })
                                    ])
                              ]))),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: GestureDetector(
                          onTap: () {
                            onTapColumnrectangle1445one(context);
                          },
                          child: Container(
                              width: size.width,
                              margin: getMargin(bottom: 177),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                        height: getVerticalSize(3.00),
                                        width: size.width,
                                        decoration: BoxDecoration(
                                            color: ColorConstant.blueGray100)),
                                    Padding(
                                        padding: getPadding(left: 16, top: 17),
                                        child: Row(children: [
                                          Card(
                                              clipBehavior: Clip.antiAlias,
                                              elevation: 0,
                                              margin: EdgeInsets.all(0),
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              19.00))),
                                              child: Container(
                                                  height:
                                                      getVerticalSize(59.00),
                                                  width:
                                                      getHorizontalSize(57.00),
                                                  padding: getPadding(
                                                      left: 10,
                                                      top: 13,
                                                      right: 10,
                                                      bottom: 13),
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              getHorizontalSize(
                                                                  19.00)),
                                                      image: DecorationImage(
                                                          image: AssetImage(
                                                              ImageConstant
                                                                  .imgGroup38),
                                                          fit: BoxFit.cover)),
                                                  child: Stack(children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgLock,
                                                        height: getVerticalSize(
                                                            30.00),
                                                        width:
                                                            getHorizontalSize(
                                                                32.00),
                                                        alignment: Alignment
                                                            .centerRight)
                                                  ]))),
                                          Padding(
                                              padding: getPadding(
                                                  left: 29, top: 19, bottom: 9),
                                              child: Text("Sign Out",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtAbhayaLibreExtraBold25Bluegray900))
                                        ])),
                                    CustomImageView(
                                        imagePath:
                                            ImageConstant.imgRectangle1444,
                                        height: getVerticalSize(23.00),
                                        width: getHorizontalSize(375.00),
                                        margin: getMargin(top: 16))
                                  ])))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          width: size.width,
                          margin: getMargin(top: 239),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(right: 48),
                                    child: Text("Aimar Cyusa Muhirwa",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtAbhayaLibreExtraBold25Bluegray900)),
                                CustomImageView(
                                    imagePath:
                                        ImageConstant.imgRectangle144420x375,
                                    height: getVerticalSize(20.00),
                                    width: getHorizontalSize(375.00),
                                    margin: getMargin(top: 22))
                              ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          width: size.width,
                          margin: getMargin(top: 126),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(left: 21),
                                    child: Row(children: [
                                      CustomImageView(
                                          imagePath: ImageConstant.imgImage1,
                                          height: getVerticalSize(43.00),
                                          width: getHorizontalSize(74.00),
                                          margin: getMargin(top: 3)),
                                      Container(
                                          height: getVerticalSize(43.00),
                                          width: getHorizontalSize(196.00),
                                          margin:
                                              getMargin(left: 28, bottom: 2),
                                          child: Stack(
                                              alignment: Alignment.bottomCenter,
                                              children: [
                                                Align(
                                                    alignment:
                                                        Alignment.topLeft,
                                                    child: Padding(
                                                        padding:
                                                            getPadding(left: 2),
                                                        child: Text(
                                                            "ALU Campus",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtAbhayaLibreExtraBold25Bluegray900))),
                                                Align(
                                                    alignment:
                                                        Alignment.bottomCenter,
                                                    child: Text(
                                                        "m.aimar@alustudent.com",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtRobotoRegular16Black900
                                                            .copyWith(
                                                                letterSpacing:
                                                                    getHorizontalSize(
                                                                        0.57))))
                                              ]))
                                    ])),
                                Container(
                                    height: getVerticalSize(3.00),
                                    width: size.width,
                                    margin: getMargin(top: 11),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.blueGray100))
                              ]))),
                  CustomImageView(
                      svgPath: ImageConstant.imgLocationGray500,
                      height: getVerticalSize(34.00),
                      width: getHorizontalSize(33.00),
                      alignment: Alignment.topLeft,
                      margin: getMargin(left: 30, top: 232))
                ]))));
  }

  onTapTxtMyBookings(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.myBookingsScreen);
  }

  onTapTxtHelp(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.helpScreen);
  }

  onTapImgTicket(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormScreen);
  }

  onTapImgMenu(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormOneScreen);
  }

  onTapImgBookmark(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.addEventScreen);
  }

  onTapColumnrectangle1445one(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.helpScreen);
  }
}
