import 'package:ccbyalu/core/app_export.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_image.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_subtitle_1.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_subtitle_2.dart';
import 'package:ccbyalu/widgets/app_bar/custom_app_bar.dart';
import 'package:ccbyalu/widgets/custom_drop_down.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class FilterScreen extends StatelessWidget {
  List<String> dropdownItemList = ["Item One", "Item Two", "Item Three"];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: size.height,
                width: size.width,
                child: Stack(alignment: Alignment.bottomCenter, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          width: size.width,
                          padding: getPadding(top: 8, bottom: 8),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder35),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomAppBar(
                                    height: getVerticalSize(38.00),
                                    leadingWidth: 52,
                                    leading: AppbarImage(
                                        height: getSize(22.00),
                                        width: getSize(22.00),
                                        svgPath: ImageConstant.imgFrame,
                                        margin:
                                            getMargin(left: 30, bottom: 16)),
                                    centerTitle: true,
                                    title: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          AppbarSubtitle2(
                                              text: "Welcome",
                                              margin:
                                                  getMargin(left: 3, right: 3)),
                                          AppbarSubtitle1(
                                              text: "Aimar M.",
                                              margin: getMargin(top: 3))
                                        ])),
                                Container(
                                    height: getVerticalSize(25.00),
                                    width: getHorizontalSize(80.00),
                                    margin: getMargin(top: 81),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.whiteA700)),
                                Spacer(),
                                Container(
                                    height: getVerticalSize(88.00),
                                    width: getHorizontalSize(339.00),
                                    child: Stack(
                                        alignment: Alignment.bottomLeft,
                                        children: [
                                          Align(
                                              alignment: Alignment.topLeft,
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Text("Duration",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtAbhayaLibreExtraBold25Bluegray900),
                                                    Container(
                                                        height: getVerticalSize(
                                                            26.00),
                                                        width:
                                                            getHorizontalSize(
                                                                27.00),
                                                        margin: getMargin(
                                                            left: 15, top: 15),
                                                        decoration: BoxDecoration(
                                                            color: ColorConstant
                                                                .whiteA700,
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        13.00)),
                                                            border: Border.all(
                                                                color:
                                                                    ColorConstant
                                                                        .gray900,
                                                                width:
                                                                    getHorizontalSize(
                                                                        1.00))))
                                                  ])),
                                          Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Padding(
                                                  padding: getPadding(left: 46),
                                                  child: Text("15mins",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtRobotoRegular16Black900
                                                          .copyWith(
                                                              letterSpacing:
                                                                  getHorizontalSize(
                                                                      0.57))))),
                                          Align(
                                              alignment: Alignment.bottomRight,
                                              child: Container(
                                                  height: getVerticalSize(3.00),
                                                  width:
                                                      getHorizontalSize(293.00),
                                                  margin: getMargin(bottom: 29),
                                                  decoration: BoxDecoration(
                                                      color: ColorConstant
                                                          .blueGray100)))
                                        ])),
                                Container(
                                    width: getHorizontalSize(314.00),
                                    margin: getMargin(top: 123),
                                    padding: getPadding(
                                        left: 30,
                                        top: 9,
                                        right: 126,
                                        bottom: 9),
                                    decoration: AppDecoration.txtFillGray90002
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .txtCircleBorder20),
                                    child: Text("Book",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtZCOOLXiaoWeiRegular20)),
                                Padding(
                                    padding: getPadding(top: 45),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          CustomImageView(
                                              svgPath: ImageConstant.imgPlay,
                                              height: getVerticalSize(18.00),
                                              width: getHorizontalSize(15.00),
                                              margin: getMargin(
                                                  top: 40, bottom: 41),
                                              onTap: () {
                                                onTapImgPlay(context);
                                              }),
                                          CustomImageView(
                                              svgPath: ImageConstant.imgTicket,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 50,
                                                  top: 37,
                                                  bottom: 38),
                                              onTap: () {
                                                onTapImgTicket(context);
                                              }),
                                          Container(
                                              width: getHorizontalSize(57.00),
                                              margin: getMargin(left: 33),
                                              padding: getPadding(
                                                  left: 16,
                                                  top: 27,
                                                  right: 16,
                                                  bottom: 27),
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              19.00)),
                                                  image: DecorationImage(
                                                      image: AssetImage(
                                                          ImageConstant
                                                              .imgGroup38),
                                                      fit: BoxFit.cover)),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgHome,
                                                        height: getSize(24.00),
                                                        width: getSize(24.00),
                                                        onTap: () {
                                                          onTapImgHome(context);
                                                        }),
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Padding(
                                                            padding: getPadding(
                                                                top: 6,
                                                                bottom: 4),
                                                            child: Text("Home",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtZCOOLXiaoWeiRegular10WhiteA700)))
                                                  ])),
                                          CustomImageView(
                                              svgPath: ImageConstant.imgMenu,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 30,
                                                  top: 37,
                                                  bottom: 38),
                                              onTap: () {
                                                onTapImgMenu(context);
                                              }),
                                          CustomImageView(
                                              svgPath:
                                                  ImageConstant.imgBookmark,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 49,
                                                  top: 37,
                                                  bottom: 38),
                                              onTap: () {
                                                onTapImgBookmark(context);
                                              })
                                        ]))
                              ]))),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                          padding: getPadding(left: 3, bottom: 226),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(left: 9),
                                    child: Text("Location",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtAbhayaLibreExtraBold25Bluegray900)),
                                CustomDropDown(
                                    width: 307,
                                    focusNode: FocusNode(),
                                    icon: Container(
                                        margin: getMargin(left: 30),
                                        child: CustomImageView(
                                            svgPath:
                                                ImageConstant.imgArrowdown)),
                                    hintText: "ALU CAMPUS",
                                    margin: getMargin(top: 13),
                                    alignment: Alignment.center,
                                    items: dropdownItemList,
                                    onChanged: (value) {}),
                                Container(
                                    height: getVerticalSize(3.00),
                                    width: getHorizontalSize(372.00),
                                    margin: getMargin(top: 13),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.blueGray100))
                              ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          width: getHorizontalSize(307.00),
                          margin: getMargin(left: 32, right: 36, bottom: 618),
                          padding: getPadding(
                              left: 23, top: 10, right: 23, bottom: 10),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                  getHorizontalSize(19.00)),
                              image: DecorationImage(
                                  image: AssetImage(ImageConstant.imgGroup38),
                                  fit: BoxFit.cover)),
                          child: Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                CustomImageView(
                                    svgPath: ImageConstant.imgBookmarkWhiteA700,
                                    height: getVerticalSize(24.00),
                                    width: getHorizontalSize(16.00),
                                    margin: getMargin(top: 146, bottom: 2)),
                                Padding(
                                    padding: getPadding(
                                        left: 24, top: 143, right: 53),
                                    child: Text("Burundi Room",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtZCOOLXiaoWeiRegular28WhiteA700))
                              ])))
                ]))));
  }

  onTapImgPlay(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.profileScreen);
  }

  onTapImgTicket(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormScreen);
  }

  onTapImgHome(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homePageScreen);
  }

  onTapImgMenu(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormOneScreen);
  }

  onTapImgBookmark(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.addEventScreen);
  }
}
