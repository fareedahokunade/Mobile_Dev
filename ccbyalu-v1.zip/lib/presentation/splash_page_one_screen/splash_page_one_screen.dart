import 'package:ccbyalu/core/app_export.dart';
import 'package:flutter/material.dart';

class SplashPageOneScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: size.height,
                width: size.width,
                child: Stack(children: [
                  Align(
                      alignment: Alignment.center,
                      child: SingleChildScrollView(
                          child: Container(
                              height: size.height,
                              width: size.width,
                              child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Align(
                                        alignment: Alignment.center,
                                        child: Container(
                                            width: size.width,
                                            padding: getPadding(
                                                left: 24,
                                                top: 49,
                                                right: 24,
                                                bottom: 49),
                                            decoration: AppDecoration
                                                .fillWhiteA700
                                                .copyWith(
                                                    borderRadius:
                                                        BorderRadiusStyle
                                                            .roundedBorder35),
                                            child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  CustomImageView(
                                                      svgPath: ImageConstant
                                                          .imgFrame,
                                                      height: getSize(22.00),
                                                      width: getSize(22.00),
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      margin:
                                                          getMargin(left: 6)),
                                                  Container(
                                                      height: getVerticalSize(
                                                          236.00),
                                                      width: getHorizontalSize(
                                                          327.00),
                                                      margin:
                                                          getMargin(top: 59),
                                                      child: Stack(
                                                          alignment: Alignment
                                                              .bottomLeft,
                                                          children: [
                                                            Align(
                                                                alignment:
                                                                    Alignment
                                                                        .topCenter,
                                                                child: Container(
                                                                    height:
                                                                        getVerticalSize(
                                                                            25.00),
                                                                    width: getHorizontalSize(
                                                                        80.00),
                                                                    margin: getMargin(
                                                                        top:
                                                                            39),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                            color:
                                                                                ColorConstant.whiteA700))),
                                                            Align(
                                                                alignment: Alignment
                                                                    .bottomLeft,
                                                                child: Padding(
                                                                    padding: getPadding(
                                                                        left:
                                                                            51),
                                                                    child: Text(
                                                                        "🥦",
                                                                        overflow:
                                                                            TextOverflow
                                                                                .ellipsis,
                                                                        textAlign:
                                                                            TextAlign
                                                                                .left,
                                                                        style: AppStyle
                                                                            .txtRobotoRegular24
                                                                            .copyWith(letterSpacing: getHorizontalSize(0.14))))),
                                                            Align(
                                                                alignment:
                                                                    Alignment
                                                                        .center,
                                                                child: Container(
                                                                    height: getVerticalSize(
                                                                        232.00),
                                                                    width: getHorizontalSize(
                                                                        327.00),
                                                                    decoration: BoxDecoration(
                                                                        color: ColorConstant
                                                                            .gray5003f,
                                                                        borderRadius:
                                                                            BorderRadius.circular(getHorizontalSize(32.00)))))
                                                          ])),
                                                  Container(
                                                      height: getVerticalSize(
                                                          193.00),
                                                      width: getHorizontalSize(
                                                          282.00),
                                                      margin: getMargin(
                                                          top: 57, right: 1),
                                                      child: Stack(
                                                          alignment: Alignment
                                                              .topRight,
                                                          children: [
                                                            Align(
                                                                alignment:
                                                                    Alignment
                                                                        .topLeft,
                                                                child: Container(
                                                                    width: getHorizontalSize(
                                                                        239.00),
                                                                    decoration:
                                                                        AppDecoration
                                                                            .txtOutlineBlack9003f,
                                                                    child: Text(
                                                                        "Campus\nCoordinator \nBy:\n",
                                                                        maxLines:
                                                                            null,
                                                                        textAlign:
                                                                            TextAlign
                                                                                .center,
                                                                        style: AppStyle
                                                                            .txtZCOOLXiaoWeiRegular34))),
                                                            CustomImageView(
                                                                imagePath:
                                                                    ImageConstant
                                                                        .imgImage1,
                                                                height: getSize(
                                                                    35.00),
                                                                width: getSize(
                                                                    35.00),
                                                                radius: BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        17.00)),
                                                                alignment:
                                                                    Alignment
                                                                        .topRight,
                                                                margin:
                                                                    getMargin(
                                                                        top:
                                                                            74)),
                                                            CustomImageView(
                                                                imagePath:
                                                                    ImageConstant
                                                                        .imgImage1,
                                                                height:
                                                                    getVerticalSize(
                                                                        74.00),
                                                                width:
                                                                    getHorizontalSize(
                                                                        101.00),
                                                                alignment: Alignment
                                                                    .bottomRight,
                                                                margin:
                                                                    getMargin(
                                                                        right:
                                                                            15))
                                                          ])),
                                                  Padding(
                                                      padding: getPadding(
                                                          top: 15,
                                                          right: 86,
                                                          bottom: 116),
                                                      child: Text(
                                                          "Book and track spaces",
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtZCOOLXiaoWeiRegular14Bluegray300))
                                                ]))),
                                    Align(
                                        alignment: Alignment.bottomCenter,
                                        child: Container(
                                            height: getVerticalSize(571.00),
                                            width: size.width,
                                            child: Stack(
                                                alignment: Alignment.topRight,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgEllipse7565,
                                                      height: getVerticalSize(
                                                          571.00),
                                                      width: getHorizontalSize(
                                                          375.00),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Padding(
                                                          padding: getPadding(
                                                              left: 87,
                                                              top: 56,
                                                              right: 68,
                                                              bottom: 496),
                                                          child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              children: [
                                                                GestureDetector(
                                                                    onTap: () {
                                                                      onTapTxtLanguage(
                                                                          context);
                                                                    },
                                                                    child: Text(
                                                                        "Log In ",
                                                                        overflow:
                                                                            TextOverflow
                                                                                .ellipsis,
                                                                        textAlign:
                                                                            TextAlign
                                                                                .left,
                                                                        style: AppStyle
                                                                            .txtZCOOLXiaoWeiRegular18)),
                                                                GestureDetector(
                                                                    onTap: () {
                                                                      onTapTxtSignUp(
                                                                          context);
                                                                    },
                                                                    child: Text(
                                                                        "Sign Up",
                                                                        overflow:
                                                                            TextOverflow
                                                                                .ellipsis,
                                                                        textAlign:
                                                                            TextAlign
                                                                                .left,
                                                                        style: AppStyle
                                                                            .txtZCOOLXiaoWeiRegular18))
                                                              ])))
                                                ]))),
                                    Align(
                                        alignment: Alignment.topCenter,
                                        child: Container(
                                            height: getVerticalSize(455.00),
                                            width: size.width,
                                            child: Stack(
                                                alignment:
                                                    Alignment.bottomCenter,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgGraphic455x375,
                                                      height: getVerticalSize(
                                                          455.00),
                                                      width: getHorizontalSize(
                                                          375.00),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment: Alignment
                                                          .bottomCenter,
                                                      child: Padding(
                                                          padding: getPadding(
                                                              left: 34,
                                                              top: 340,
                                                              right: 37,
                                                              bottom: 5),
                                                          child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Container(
                                                                    height:
                                                                        getVerticalSize(
                                                                            46.00),
                                                                    width: getHorizontalSize(
                                                                        70.00),
                                                                    margin: getMargin(
                                                                        bottom:
                                                                            63),
                                                                    child: Stack(
                                                                        alignment:
                                                                            Alignment.topLeft,
                                                                        children: [
                                                                          Align(
                                                                              alignment: Alignment.bottomCenter,
                                                                              child: Container(
                                                                                  height: getVerticalSize(14.00),
                                                                                  width: getHorizontalSize(70.00),
                                                                                  child: Stack(alignment: Alignment.centerLeft, children: [
                                                                                    CustomImageView(imagePath: ImageConstant.imgShadow, height: getVerticalSize(14.00), width: getHorizontalSize(70.00), alignment: Alignment.center),
                                                                                    CustomImageView(imagePath: ImageConstant.imgShadow14x37, height: getVerticalSize(14.00), width: getHorizontalSize(37.00), alignment: Alignment.centerLeft)
                                                                                  ]))),
                                                                          Align(
                                                                              alignment: Alignment.topLeft,
                                                                              child: Container(
                                                                                  height: getVerticalSize(42.00),
                                                                                  width: getHorizontalSize(30.00),
                                                                                  margin: getMargin(left: 2),
                                                                                  child: Stack(alignment: Alignment.center, children: [
                                                                                    CustomImageView(imagePath: ImageConstant.imgBase, height: getVerticalSize(42.00), width: getHorizontalSize(30.00), alignment: Alignment.center),
                                                                                    Align(
                                                                                        alignment: Alignment.center,
                                                                                        child: Container(
                                                                                            height: getVerticalSize(42.00),
                                                                                            width: getHorizontalSize(30.00),
                                                                                            child: Stack(alignment: Alignment.center, children: [
                                                                                              CustomImageView(imagePath: ImageConstant.imgBase, height: getVerticalSize(42.00), width: getHorizontalSize(30.00), alignment: Alignment.center),
                                                                                              Align(
                                                                                                  alignment: Alignment.center,
                                                                                                  child: Container(
                                                                                                      height: getVerticalSize(42.00),
                                                                                                      width: getHorizontalSize(30.00),
                                                                                                      child: Stack(alignment: Alignment.topCenter, children: [
                                                                                                        Align(
                                                                                                            alignment: Alignment.bottomRight,
                                                                                                            child: Container(
                                                                                                                width: getHorizontalSize(18.00),
                                                                                                                margin: getMargin(right: 3, bottom: 5),
                                                                                                                child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.start, children: [
                                                                                                                  Container(
                                                                                                                      height: getVerticalSize(10.00),
                                                                                                                      width: getHorizontalSize(17.00),
                                                                                                                      child: Stack(alignment: Alignment.center, children: [
                                                                                                                        CustomImageView(imagePath: ImageConstant.imgImage, height: getVerticalSize(10.00), width: getHorizontalSize(17.00), alignment: Alignment.center),
                                                                                                                        Align(
                                                                                                                            alignment: Alignment.center,
                                                                                                                            child: Container(
                                                                                                                                height: getVerticalSize(10.00),
                                                                                                                                width: getHorizontalSize(17.00),
                                                                                                                                child: Stack(alignment: Alignment.centerRight, children: [
                                                                                                                                  CustomImageView(imagePath: ImageConstant.imgImage, height: getVerticalSize(10.00), width: getHorizontalSize(17.00), alignment: Alignment.center),
                                                                                                                                  Align(
                                                                                                                                      alignment: Alignment.centerRight,
                                                                                                                                      child: Container(
                                                                                                                                          height: getVerticalSize(7.00),
                                                                                                                                          width: getHorizontalSize(10.00),
                                                                                                                                          margin: getMargin(right: 3),
                                                                                                                                          child: Stack(alignment: Alignment.center, children: [
                                                                                                                                            CustomImageView(imagePath: ImageConstant.imgMoumtain, height: getVerticalSize(7.00), width: getHorizontalSize(10.00), alignment: Alignment.center),
                                                                                                                                            CustomImageView(imagePath: ImageConstant.imgMoumtain, height: getVerticalSize(7.00), width: getHorizontalSize(10.00), alignment: Alignment.center)
                                                                                                                                          ])))
                                                                                                                                ])))
                                                                                                                      ])),
                                                                                                                  Align(
                                                                                                                      alignment: Alignment.centerRight,
                                                                                                                      child: Container(
                                                                                                                          height: getVerticalSize(15.00),
                                                                                                                          width: getHorizontalSize(16.00),
                                                                                                                          margin: getMargin(top: 1),
                                                                                                                          child: Stack(alignment: Alignment.center, children: [
                                                                                                                            CustomImageView(imagePath: ImageConstant.imgCircles, height: getVerticalSize(15.00), width: getHorizontalSize(16.00), alignment: Alignment.center),
                                                                                                                            CustomImageView(imagePath: ImageConstant.imgCircles, height: getVerticalSize(15.00), width: getHorizontalSize(16.00), alignment: Alignment.center)
                                                                                                                          ])))
                                                                                                                ]))),
                                                                                                        Align(
                                                                                                            alignment: Alignment.topCenter,
                                                                                                            child: Container(
                                                                                                                height: getVerticalSize(7.00),
                                                                                                                width: getHorizontalSize(20.00),
                                                                                                                child: Stack(alignment: Alignment.center, children: [
                                                                                                                  CustomImageView(imagePath: ImageConstant.img2, height: getVerticalSize(7.00), width: getHorizontalSize(20.00), alignment: Alignment.center),
                                                                                                                  CustomImageView(imagePath: ImageConstant.img2, height: getVerticalSize(7.00), width: getHorizontalSize(20.00), alignment: Alignment.center)
                                                                                                                ]))),
                                                                                                        Align(
                                                                                                            alignment: Alignment.center,
                                                                                                            child: Container(
                                                                                                                height: getVerticalSize(42.00),
                                                                                                                width: getHorizontalSize(30.00),
                                                                                                                child: Stack(alignment: Alignment.center, children: [
                                                                                                                  CustomImageView(imagePath: ImageConstant.imgSpecular, height: getVerticalSize(42.00), width: getHorizontalSize(30.00), alignment: Alignment.center),
                                                                                                                  Align(
                                                                                                                      alignment: Alignment.center,
                                                                                                                      child: Container(
                                                                                                                          height: getVerticalSize(42.00),
                                                                                                                          width: getHorizontalSize(30.00),
                                                                                                                          child: Stack(alignment: Alignment.center, children: [
                                                                                                                            CustomImageView(imagePath: ImageConstant.imgSpecular, height: getVerticalSize(42.00), width: getHorizontalSize(30.00), alignment: Alignment.center),
                                                                                                                            CustomImageView(imagePath: ImageConstant.imgSpecular, height: getVerticalSize(42.00), width: getHorizontalSize(30.00), alignment: Alignment.center)
                                                                                                                          ])))
                                                                                                                ])))
                                                                                                      ])))
                                                                                            ])))
                                                                                  ])))
                                                                        ])),
                                                                Container(
                                                                    height:
                                                                        getSize(
                                                                            5.00),
                                                                    width:
                                                                        getSize(
                                                                            5.00),
                                                                    margin: getMargin(
                                                                        left:
                                                                            17,
                                                                        top: 28,
                                                                        bottom:
                                                                            77),
                                                                    decoration: BoxDecoration(
                                                                        color: ColorConstant
                                                                            .amber30075,
                                                                        borderRadius:
                                                                            BorderRadius.circular(getHorizontalSize(2.00)))),
                                                                Spacer(
                                                                    flex: 29),
                                                                Container(
                                                                    height:
                                                                        getSize(
                                                                            5.00),
                                                                    width:
                                                                        getSize(
                                                                            5.00),
                                                                    margin: getMargin(
                                                                        top: 66,
                                                                        bottom:
                                                                            39),
                                                                    decoration: BoxDecoration(
                                                                        color: ColorConstant
                                                                            .blueA1007e,
                                                                        borderRadius:
                                                                            BorderRadius.circular(getHorizontalSize(2.00)))),
                                                                Spacer(
                                                                    flex: 70),
                                                                Container(
                                                                    height:
                                                                        getSize(
                                                                            9.00),
                                                                    width:
                                                                        getSize(
                                                                            9.00),
                                                                    margin: getMargin(
                                                                        top:
                                                                            101),
                                                                    decoration: BoxDecoration(
                                                                        color: ColorConstant
                                                                            .amber30075,
                                                                        borderRadius:
                                                                            BorderRadius.circular(getHorizontalSize(4.00))))
                                                              ])))
                                                ]))),
                                    Align(
                                        alignment: Alignment.bottomLeft,
                                        child: Container(
                                            height: getVerticalSize(59.00),
                                            width: getHorizontalSize(35.00),
                                            margin: getMargin(bottom: 270),
                                            child: Stack(
                                                alignment: Alignment.center,
                                                children: [
                                                  CustomImageView(
                                                      imagePath:
                                                          ImageConstant.imgCube,
                                                      height: getVerticalSize(
                                                          59.00),
                                                      width: getHorizontalSize(
                                                          35.00),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  59.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  35.00),
                                                          child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgCube,
                                                                    height:
                                                                        getVerticalSize(
                                                                            59.00),
                                                                    width: getHorizontalSize(
                                                                        35.00),
                                                                    alignment:
                                                                        Alignment
                                                                            .center),
                                                                Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child: Container(
                                                                        height: getVerticalSize(59.00),
                                                                        width: getHorizontalSize(35.00),
                                                                        child: Stack(alignment: Alignment.center, children: [
                                                                          CustomImageView(
                                                                              imagePath: ImageConstant.imgSpecular59x35,
                                                                              height: getVerticalSize(59.00),
                                                                              width: getHorizontalSize(35.00),
                                                                              alignment: Alignment.center),
                                                                          Align(
                                                                              alignment: Alignment.center,
                                                                              child: Container(
                                                                                  height: getVerticalSize(59.00),
                                                                                  width: getHorizontalSize(35.00),
                                                                                  child: Stack(alignment: Alignment.center, children: [
                                                                                    CustomImageView(imagePath: ImageConstant.imgSpecular59x35, height: getVerticalSize(59.00), width: getHorizontalSize(35.00), alignment: Alignment.center),
                                                                                    CustomImageView(imagePath: ImageConstant.imgSpecular59x35, height: getVerticalSize(59.00), width: getHorizontalSize(35.00), alignment: Alignment.center)
                                                                                  ])))
                                                                        ])))
                                                              ])))
                                                ]))),
                                    Align(
                                        alignment: Alignment.bottomLeft,
                                        child: Container(
                                            height: getVerticalSize(45.00),
                                            width: getHorizontalSize(107.00),
                                            margin: getMargin(bottom: 133),
                                            child: Stack(
                                                alignment: Alignment.topRight,
                                                children: [
                                                  Align(
                                                      alignment: Alignment
                                                          .bottomCenter,
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  21.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  107.00),
                                                          child: Stack(
                                                              alignment: Alignment
                                                                  .centerRight,
                                                              children: [
                                                                CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgShadow21x107,
                                                                    height:
                                                                        getVerticalSize(
                                                                            21.00),
                                                                    width: getHorizontalSize(
                                                                        107.00),
                                                                    alignment:
                                                                        Alignment
                                                                            .center),
                                                                CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgShadow21x46,
                                                                    height:
                                                                        getVerticalSize(
                                                                            21.00),
                                                                    width: getHorizontalSize(
                                                                        46.00),
                                                                    alignment:
                                                                        Alignment
                                                                            .centerRight,
                                                                    margin: getMargin(
                                                                        right:
                                                                            18))
                                                              ]))),
                                                  Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  30.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  26.00),
                                                          margin: getMargin(
                                                              right: 28),
                                                          child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgBase30x26,
                                                                    height:
                                                                        getVerticalSize(
                                                                            30.00),
                                                                    width: getHorizontalSize(
                                                                        26.00),
                                                                    alignment:
                                                                        Alignment
                                                                            .center),
                                                                Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child: Container(
                                                                        height: getVerticalSize(30.00),
                                                                        width: getHorizontalSize(26.00),
                                                                        child: Stack(alignment: Alignment.center, children: [
                                                                          CustomImageView(
                                                                              imagePath: ImageConstant.imgBase30x26,
                                                                              height: getVerticalSize(30.00),
                                                                              width: getHorizontalSize(26.00),
                                                                              alignment: Alignment.center),
                                                                          Align(
                                                                              alignment: Alignment.center,
                                                                              child: Container(
                                                                                  height: getVerticalSize(30.00),
                                                                                  width: getHorizontalSize(26.00),
                                                                                  child: Stack(alignment: Alignment.topCenter, children: [
                                                                                    Align(
                                                                                        alignment: Alignment.topRight,
                                                                                        child: Container(
                                                                                            height: getSize(3.00),
                                                                                            width: getSize(3.00),
                                                                                            margin: getMargin(top: 12, right: 9),
                                                                                            child: Stack(alignment: Alignment.center, children: [
                                                                                              CustomImageView(imagePath: ImageConstant.img1, height: getSize(3.00), width: getSize(3.00), alignment: Alignment.center),
                                                                                              CustomImageView(imagePath: ImageConstant.img1, height: getSize(3.00), width: getSize(3.00), alignment: Alignment.center)
                                                                                            ]))),
                                                                                    Align(
                                                                                        alignment: Alignment.topCenter,
                                                                                        child: Container(
                                                                                            height: getVerticalSize(6.00),
                                                                                            width: getHorizontalSize(3.00),
                                                                                            margin: getMargin(top: 6),
                                                                                            child: Stack(alignment: Alignment.center, children: [
                                                                                              CustomImageView(imagePath: ImageConstant.imgMin, height: getVerticalSize(6.00), width: getHorizontalSize(3.00), alignment: Alignment.center),
                                                                                              CustomImageView(imagePath: ImageConstant.imgMin, height: getVerticalSize(6.00), width: getHorizontalSize(3.00), alignment: Alignment.center)
                                                                                            ]))),
                                                                                    Align(
                                                                                        alignment: Alignment.topRight,
                                                                                        child: Container(
                                                                                            height: getVerticalSize(3.00),
                                                                                            width: getHorizontalSize(4.00),
                                                                                            margin: getMargin(top: 10, right: 6),
                                                                                            child: Stack(alignment: Alignment.center, children: [
                                                                                              CustomImageView(imagePath: ImageConstant.imgHr, height: getVerticalSize(3.00), width: getHorizontalSize(4.00), alignment: Alignment.center),
                                                                                              CustomImageView(imagePath: ImageConstant.imgHr, height: getVerticalSize(3.00), width: getHorizontalSize(4.00), alignment: Alignment.center)
                                                                                            ]))),
                                                                                    Align(
                                                                                        alignment: Alignment.center,
                                                                                        child: Container(
                                                                                            height: getVerticalSize(30.00),
                                                                                            width: getHorizontalSize(26.00),
                                                                                            child: Stack(alignment: Alignment.center, children: [
                                                                                              CustomImageView(imagePath: ImageConstant.imgSpecular30x26, height: getVerticalSize(30.00), width: getHorizontalSize(26.00), alignment: Alignment.center),
                                                                                              Align(
                                                                                                  alignment: Alignment.center,
                                                                                                  child: Container(
                                                                                                      height: getVerticalSize(30.00),
                                                                                                      width: getHorizontalSize(26.00),
                                                                                                      child: Stack(alignment: Alignment.center, children: [
                                                                                                        CustomImageView(imagePath: ImageConstant.imgSpecular30x26, height: getVerticalSize(30.00), width: getHorizontalSize(26.00), alignment: Alignment.center),
                                                                                                        CustomImageView(imagePath: ImageConstant.imgSpecular30x26, height: getVerticalSize(30.00), width: getHorizontalSize(26.00), alignment: Alignment.center)
                                                                                                      ])))
                                                                                            ])))
                                                                                  ])))
                                                                        ])))
                                                              ])))
                                                ]))),
                                    Align(
                                        alignment: Alignment.bottomRight,
                                        child: Container(
                                            height: getVerticalSize(59.00),
                                            width: getHorizontalSize(38.00),
                                            margin: getMargin(bottom: 155),
                                            child: Stack(
                                                alignment: Alignment.center,
                                                children: [
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgCube59x38,
                                                      height: getVerticalSize(
                                                          59.00),
                                                      width: getHorizontalSize(
                                                          38.00),
                                                      alignment:
                                                          Alignment.center),
                                                  Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  59.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  38.00),
                                                          child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgCube59x38,
                                                                    height:
                                                                        getVerticalSize(
                                                                            59.00),
                                                                    width: getHorizontalSize(
                                                                        38.00),
                                                                    alignment:
                                                                        Alignment
                                                                            .center),
                                                                Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child: Container(
                                                                        height: getVerticalSize(59.00),
                                                                        width: getHorizontalSize(38.00),
                                                                        child: Stack(alignment: Alignment.center, children: [
                                                                          CustomImageView(
                                                                              imagePath: ImageConstant.imgSpecular59x38,
                                                                              height: getVerticalSize(59.00),
                                                                              width: getHorizontalSize(38.00),
                                                                              alignment: Alignment.center),
                                                                          Align(
                                                                              alignment: Alignment.center,
                                                                              child: Container(
                                                                                  height: getVerticalSize(59.00),
                                                                                  width: getHorizontalSize(38.00),
                                                                                  child: Stack(alignment: Alignment.center, children: [
                                                                                    CustomImageView(imagePath: ImageConstant.imgSpecular59x38, height: getVerticalSize(59.00), width: getHorizontalSize(38.00), alignment: Alignment.center),
                                                                                    CustomImageView(imagePath: ImageConstant.imgSpecular59x38, height: getVerticalSize(59.00), width: getHorizontalSize(38.00), alignment: Alignment.center)
                                                                                  ])))
                                                                        ])))
                                                              ])))
                                                ])))
                                  ]))))
                ]))));
  }

  onTapTxtLanguage(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.logInScreen);
  }

  onTapTxtSignUp(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signUpScreen);
  }
}
