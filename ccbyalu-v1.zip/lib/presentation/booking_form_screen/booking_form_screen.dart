import 'package:ccbyalu/core/app_export.dart';
import 'package:flutter/material.dart';

class BookingFormScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: size.height,
                width: size.width,
                child: Stack(alignment: Alignment.topRight, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          width: size.width,
                          padding: getPadding(
                              left: 10, top: 8, right: 10, bottom: 8),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder35),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Spacer(),
                                Container(
                                    height: getVerticalSize(25.00),
                                    width: getHorizontalSize(80.00),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.whiteA700)),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Container(
                                        width: getHorizontalSize(165.00),
                                        margin: getMargin(left: 3, top: 23),
                                        padding: getPadding(
                                            left: 34,
                                            top: 14,
                                            right: 34,
                                            bottom: 14),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                                getHorizontalSize(19.00)),
                                            image: DecorationImage(
                                                image: AssetImage(
                                                    ImageConstant.imgGroup38),
                                                fit: BoxFit.cover)),
                                        child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              Padding(
                                                  padding: getPadding(
                                                      left: 31, top: 15),
                                                  child: Text("2",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtZCOOLXiaoWeiRegular40)),
                                              Align(
                                                  alignment:
                                                      Alignment.centerRight,
                                                  child: Padding(
                                                      padding: getPadding(
                                                          top: 9, right: 9),
                                                      child: Text("PEOPLE",
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtZCOOLXiaoWeiRegular20))),
                                              Padding(
                                                  padding: getPadding(top: 17),
                                                  child: Text("Burundi Room",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtZCOOLXiaoWeiRegular15))
                                            ]))),
                                Padding(
                                    padding: getPadding(left: 3, top: 17),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                              height: getVerticalSize(145.00),
                                              width: getHorizontalSize(165.00),
                                              margin: getMargin(top: 1),
                                              child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Align(
                                                        alignment: Alignment
                                                            .bottomRight,
                                                        child: Padding(
                                                            padding: getPadding(
                                                                right: 44,
                                                                bottom: 23),
                                                            child: Text(
                                                                "PEOPLE",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtZCOOLXiaoWeiRegular20))),
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Container(
                                                            width:
                                                                getHorizontalSize(
                                                                    165.00),
                                                            padding: getPadding(
                                                                left: 12,
                                                                top: 6,
                                                                right: 12,
                                                                bottom: 6),
                                                            decoration: BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius.circular(
                                                                        getHorizontalSize(
                                                                            19.00)),
                                                                image: DecorationImage(
                                                                    image: AssetImage(
                                                                        ImageConstant
                                                                            .imgGroup38),
                                                                    fit: BoxFit
                                                                        .cover)),
                                                            child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                children: [
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              42,
                                                                          top:
                                                                              32),
                                                                      child: Text(
                                                                          "20",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtZCOOLXiaoWeiRegular40)),
                                                                  Align(
                                                                      alignment:
                                                                          Alignment
                                                                              .centerRight,
                                                                      child: Padding(
                                                                          padding: getPadding(
                                                                              top:
                                                                                  11,
                                                                              right:
                                                                                  32),
                                                                          child: Text(
                                                                              "PEOPLE",
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtZCOOLXiaoWeiRegular20))),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          top:
                                                                              2),
                                                                      child: Row(
                                                                          children: [
                                                                            CustomImageView(
                                                                                svgPath: ImageConstant.imgBookmarkWhiteA700,
                                                                                height: getVerticalSize(24.00),
                                                                                width: getHorizontalSize(16.00)),
                                                                            Padding(
                                                                                padding: getPadding(left: 12, top: 8),
                                                                                child: Text("Lagos Room", overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtZCOOLXiaoWeiRegular15))
                                                                          ]))
                                                                ])))
                                                  ])),
                                          Container(
                                              height: getVerticalSize(145.00),
                                              width: getHorizontalSize(165.00),
                                              margin: getMargin(bottom: 1),
                                              child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Align(
                                                        alignment: Alignment
                                                            .bottomLeft,
                                                        child: Container(
                                                            margin: getMargin(
                                                                left: 8),
                                                            padding: getPadding(
                                                                left: 2,
                                                                right: 2),
                                                            decoration: AppDecoration
                                                                .fillGray50
                                                                .copyWith(
                                                                    borderRadius:
                                                                        BorderRadiusStyle
                                                                            .roundedBorder17),
                                                            child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .end,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                children: [
                                                                  Container(
                                                                      height: getSize(
                                                                          22.00),
                                                                      width: getSize(
                                                                          22.00),
                                                                      margin: getMargin(
                                                                          top:
                                                                              7),
                                                                      decoration: BoxDecoration(
                                                                          color: ColorConstant
                                                                              .green30075,
                                                                          borderRadius:
                                                                              BorderRadius.circular(getHorizontalSize(11.00))))
                                                                ]))),
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Container(
                                                            width:
                                                                getHorizontalSize(
                                                                    165.00),
                                                            padding: getPadding(
                                                                left: 12,
                                                                top: 4,
                                                                right: 12,
                                                                bottom: 4),
                                                            decoration: BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius.circular(
                                                                        getHorizontalSize(
                                                                            19.00)),
                                                                image: DecorationImage(
                                                                    image: AssetImage(
                                                                        ImageConstant
                                                                            .imgGroup38),
                                                                    fit: BoxFit
                                                                        .cover)),
                                                            child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                children: [
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              47,
                                                                          top:
                                                                              35),
                                                                      child: Text(
                                                                          "10",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtZCOOLXiaoWeiRegular40)),
                                                                  Align(
                                                                      alignment:
                                                                          Alignment
                                                                              .center,
                                                                      child: Padding(
                                                                          padding: getPadding(
                                                                              top:
                                                                                  11),
                                                                          child: Text(
                                                                              "PEOPLE",
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtZCOOLXiaoWeiRegular20))),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          top:
                                                                              1),
                                                                      child: Row(
                                                                          children: [
                                                                            CustomImageView(
                                                                                svgPath: ImageConstant.imgBookmarkWhiteA70026x16,
                                                                                height: getVerticalSize(26.00),
                                                                                width: getHorizontalSize(16.00)),
                                                                            Padding(
                                                                                padding: getPadding(left: 8, top: 7, bottom: 3),
                                                                                child: Text("Namibia Room", overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtZCOOLXiaoWeiRegular15))
                                                                          ]))
                                                                ])))
                                                  ]))
                                        ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 17),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                              width: getHorizontalSize(165.00),
                                              padding: getPadding(
                                                  left: 12,
                                                  top: 10,
                                                  right: 12,
                                                  bottom: 10),
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              19.00)),
                                                  image: DecorationImage(
                                                      image: AssetImage(
                                                          ImageConstant
                                                              .imgGroup38),
                                                      fit: BoxFit.cover)),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: [
                                                    Padding(
                                                        padding: getPadding(
                                                            left: 54, top: 32),
                                                        child: Text("3",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular40)),
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Padding(
                                                            padding: getPadding(
                                                                top: 2),
                                                            child: Text(
                                                                "PEOPLE",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtZCOOLXiaoWeiRegular20))),
                                                    Padding(
                                                        padding:
                                                            getPadding(top: 4),
                                                        child: Row(children: [
                                                          CustomImageView(
                                                              svgPath: ImageConstant
                                                                  .imgBookmarkWhiteA700,
                                                              height:
                                                                  getVerticalSize(
                                                                      24.00),
                                                              width:
                                                                  getHorizontalSize(
                                                                      16.00)),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      left: 11,
                                                                      top: 8),
                                                              child: Text(
                                                                  "Gambia Room",
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtZCOOLXiaoWeiRegular15))
                                                        ]))
                                                  ])),
                                          Container(
                                              width: getHorizontalSize(165.00),
                                              padding: getPadding(
                                                  left: 12,
                                                  top: 6,
                                                  right: 12,
                                                  bottom: 6),
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              19.00)),
                                                  image: DecorationImage(
                                                      image: AssetImage(
                                                          ImageConstant
                                                              .imgGroup38),
                                                      fit: BoxFit.cover)),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: [
                                                    Padding(
                                                        padding:
                                                            getPadding(top: 35),
                                                        child: Text("1",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular40)),
                                                    Padding(
                                                        padding:
                                                            getPadding(top: 6),
                                                        child: Text("PERSON",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular20)),
                                                    Align(
                                                        alignment: Alignment
                                                            .centerLeft,
                                                        child: Padding(
                                                            padding: getPadding(
                                                                top: 2),
                                                            child: Row(
                                                                children: [
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgBookmarkWhiteA70026x16,
                                                                      height: getVerticalSize(
                                                                          26.00),
                                                                      width: getHorizontalSize(
                                                                          16.00)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              12,
                                                                          top:
                                                                              6,
                                                                          bottom:
                                                                              4),
                                                                      child: Text(
                                                                          "Guinea Room",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtZCOOLXiaoWeiRegular15))
                                                                ])))
                                                  ]))
                                        ])),
                                Padding(
                                    padding: getPadding(top: 18),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          CustomImageView(
                                              svgPath: ImageConstant.imgPlay,
                                              height: getVerticalSize(18.00),
                                              width: getHorizontalSize(15.00),
                                              margin: getMargin(
                                                  top: 40, bottom: 41),
                                              onTap: () {
                                                onTapImgPlay(context);
                                              }),
                                          CustomImageView(
                                              svgPath: ImageConstant.imgTicket,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 50,
                                                  top: 37,
                                                  bottom: 38)),
                                          Container(
                                              width: getHorizontalSize(57.00),
                                              margin: getMargin(left: 33),
                                              padding: getPadding(
                                                  left: 16,
                                                  top: 27,
                                                  right: 16,
                                                  bottom: 27),
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              19.00)),
                                                  image: DecorationImage(
                                                      image: AssetImage(
                                                          ImageConstant
                                                              .imgGroup38),
                                                      fit: BoxFit.cover)),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgHome,
                                                        height: getSize(24.00),
                                                        width: getSize(24.00),
                                                        onTap: () {
                                                          onTapImgHome(context);
                                                        }),
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Padding(
                                                            padding: getPadding(
                                                                top: 6,
                                                                bottom: 4),
                                                            child: Text("Home",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtZCOOLXiaoWeiRegular10WhiteA700)))
                                                  ])),
                                          CustomImageView(
                                              svgPath: ImageConstant.imgMenu,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 30,
                                                  top: 37,
                                                  bottom: 38),
                                              onTap: () {
                                                onTapImgMenu(context);
                                              }),
                                          CustomImageView(
                                              svgPath:
                                                  ImageConstant.imgBookmark,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 49,
                                                  top: 37,
                                                  bottom: 38),
                                              onTap: () {
                                                onTapImgBookmarkFour(context);
                                              })
                                        ]))
                              ]))),
                  CustomImageView(
                      imagePath: ImageConstant.imgFilterWhiteA700,
                      height: getVerticalSize(110.00),
                      width: getHorizontalSize(56.00),
                      alignment: Alignment.topRight,
                      margin: getMargin(top: 134),
                      onTap: () {
                        onTapImgFilter(context);
                      }),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          height: getVerticalSize(157.00),
                          width: size.width,
                          child:
                              Stack(alignment: Alignment.topCenter, children: [
                            CustomImageView(
                                imagePath: ImageConstant.imgEllipse7561,
                                height: getVerticalSize(157.00),
                                width: getHorizontalSize(375.00),
                                alignment: Alignment.center),
                            Align(
                                alignment: Alignment.topCenter,
                                child: Padding(
                                    padding: getPadding(top: 60),
                                    child: Text("Available Rooms",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtZCOOLXiaoWeiRegular28WhiteA700)))
                          ]))),
                  Align(
                      alignment: Alignment.topRight,
                      child: Container(
                          width: getHorizontalSize(165.00),
                          margin: getMargin(top: 217, right: 13),
                          padding: getPadding(
                              left: 12, top: 7, right: 12, bottom: 7),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                  getHorizontalSize(19.00)),
                              image: DecorationImage(
                                  image: AssetImage(ImageConstant.imgGroup38),
                                  fit: BoxFit.cover)),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Align(
                                    alignment: Alignment.center,
                                    child: Padding(
                                        padding: getPadding(top: 22),
                                        child: Text("5",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtZCOOLXiaoWeiRegular40))),
                                Padding(
                                    padding: getPadding(left: 31, top: 12),
                                    child: Text("PEOPLE",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtZCOOLXiaoWeiRegular20)),
                                Padding(
                                    padding: getPadding(top: 8),
                                    child: Row(children: [
                                      CustomImageView(
                                          svgPath: ImageConstant
                                              .imgBookmarkWhiteA70026x16,
                                          height: getVerticalSize(26.00),
                                          width: getHorizontalSize(16.00)),
                                      Padding(
                                          padding: getPadding(
                                              left: 25, top: 5, bottom: 5),
                                          child: Text("Leap Pod",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtZCOOLXiaoWeiRegular15))
                                    ]))
                              ])))
                ]))));
  }

  onTapImgPlay(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.profileScreen);
  }

  onTapImgHome(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homePageScreen);
  }

  onTapImgMenu(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormOneScreen);
  }

  onTapImgBookmarkFour(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.addEventScreen);
  }

  onTapImgFilter(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.filterOneScreen);
  }
}
