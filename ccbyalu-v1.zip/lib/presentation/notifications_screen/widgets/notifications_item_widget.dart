import 'package:ccbyalu/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class NotificationsItemWidget extends StatelessWidget {
  NotificationsItemWidget();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomImageView(
          imagePath: ImageConstant.imgImage1,
          height: getVerticalSize(
            74.00,
          ),
          width: getHorizontalSize(
            101.00,
          ),
          margin: getMargin(
            bottom: 21,
          ),
        ),
        Container(
          width: getHorizontalSize(
            156.00,
          ),
          margin: getMargin(
            left: 18,
            top: 16,
          ),
          child: Text(
            "ALU CAMPUS\nMaintenance Upda...\n\nHello Students, the,",
            maxLines: null,
            textAlign: TextAlign.left,
            style: AppStyle.txtRobotoRegular16Black900.copyWith(
              letterSpacing: getHorizontalSize(
                0.57,
              ),
            ),
          ),
        ),
        Container(
          width: getHorizontalSize(
            51.00,
          ),
          margin: getMargin(
            left: 20,
            top: 11,
            bottom: 45,
          ),
          child: Text(
            "19 Tue\n1:30",
            maxLines: null,
            textAlign: TextAlign.right,
            style: AppStyle.txtRobotoRegular16Black900.copyWith(
              letterSpacing: getHorizontalSize(
                0.57,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
