import '../notifications_screen/widgets/notifications_item_widget.dart';
import 'package:ccbyalu/core/app_export.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_image.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_subtitle.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_subtitle_1.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_subtitle_2.dart';
import 'package:ccbyalu/widgets/app_bar/appbar_title.dart';
import 'package:ccbyalu/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: size.height,
                width: size.width,
                child: Stack(alignment: Alignment.bottomCenter, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          margin: getMargin(right: 1),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder35),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomAppBar(
                                    height: getVerticalSize(50.00),
                                    title: Row(children: [
                                      Container(
                                          height: getVerticalSize(50.36),
                                          width: getHorizontalSize(35.14),
                                          margin: getMargin(left: 16),
                                          child: Stack(
                                              alignment: Alignment.bottomLeft,
                                              children: [
                                                AppbarTitle(
                                                    text: "x",
                                                    margin: getMargin(
                                                        right: 19, bottom: 15)),
                                                AppbarImage(
                                                    height: getSize(22.00),
                                                    width: getSize(22.00),
                                                    svgPath:
                                                        ImageConstant.imgFrame,
                                                    margin: getMargin(
                                                        left: 13, top: 28))
                                              ])),
                                      Container(
                                          height: getVerticalSize(45.82),
                                          width: getHorizontalSize(186.66),
                                          margin:
                                              getMargin(left: 25, bottom: 3),
                                          child: Stack(
                                              alignment: Alignment.bottomCenter,
                                              children: [
                                                AppbarSubtitle2(
                                                    text: "Welcome",
                                                    margin: getMargin(
                                                        left: 83,
                                                        top: 12,
                                                        right: 48,
                                                        bottom: 19)),
                                                AppbarSubtitle1(
                                                    text: "Aimar M.",
                                                    margin: getMargin(
                                                        left: 80,
                                                        top: 29,
                                                        right: 44)),
                                                AppbarSubtitle(
                                                    text: "Notifications",
                                                    margin: getMargin(
                                                        left: 36, bottom: 16)),
                                                AppbarSubtitle2(
                                                    text: "Welcome",
                                                    margin: getMargin(
                                                        left: 83,
                                                        top: 12,
                                                        right: 48,
                                                        bottom: 19)),
                                                AppbarSubtitle1(
                                                    text: "Aimar M.",
                                                    margin: getMargin(
                                                        left: 80,
                                                        top: 29,
                                                        right: 44)),
                                                AppbarSubtitle(
                                                    text: "Notifications",
                                                    margin: getMargin(
                                                        left: 36, bottom: 16)),
                                                AppbarSubtitle2(
                                                    text: "Welcome",
                                                    margin: getMargin(
                                                        left: 83,
                                                        top: 5,
                                                        right: 48,
                                                        bottom: 26)),
                                                AppbarSubtitle1(
                                                    text: "Aimar M.",
                                                    margin: getMargin(
                                                        left: 80,
                                                        top: 21,
                                                        right: 44,
                                                        bottom: 16)),
                                                AppbarSubtitle(
                                                    text: "Notifications",
                                                    margin: getMargin(
                                                        left: 36, bottom: 24)),
                                                AppbarSubtitle2(
                                                    text: "Welcome",
                                                    margin: getMargin(
                                                        left: 3,
                                                        top: 7,
                                                        right: 128,
                                                        bottom: 24)),
                                                AppbarSubtitle1(
                                                    text: "Aimar M.",
                                                    margin: getMargin(
                                                        top: 16,
                                                        right: 124,
                                                        bottom: 13))
                                              ]))
                                    ]),
                                    actions: [
                                      AppbarImage(
                                          height: getSize(22.00),
                                          width: getSize(22.00),
                                          svgPath: ImageConstant.imgLightbulb,
                                          margin: getMargin(
                                              left: 28, top: 28, right: 28))
                                    ]),
                                Container(
                                    height: getVerticalSize(114.00),
                                    width: getHorizontalSize(371.00),
                                    margin: getMargin(top: 9),
                                    child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Align(
                                              alignment: Alignment.bottomCenter,
                                              child: Container(
                                                  height:
                                                      getVerticalSize(25.00),
                                                  width:
                                                      getHorizontalSize(80.00),
                                                  decoration: BoxDecoration(
                                                      color: ColorConstant
                                                          .whiteA700))),
                                          Align(
                                              alignment: Alignment.center,
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Padding(
                                                        padding: getPadding(
                                                            left: 9, right: 15),
                                                        child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              CustomImageView(
                                                                  imagePath:
                                                                      ImageConstant
                                                                          .imgImage1,
                                                                  height:
                                                                      getVerticalSize(
                                                                          74.00),
                                                                  width:
                                                                      getHorizontalSize(
                                                                          101.00),
                                                                  margin: getMargin(
                                                                      bottom:
                                                                          21)),
                                                              Container(
                                                                  width: getHorizontalSize(
                                                                      156.00),
                                                                  margin:
                                                                      getMargin(
                                                                          top:
                                                                              16),
                                                                  child: Text(
                                                                      "ALU CAMPUS\nMaintenance Upda...\n\nHello Students, the,",
                                                                      maxLines:
                                                                          null,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtRobotoRegular16Black900
                                                                          .copyWith(
                                                                              letterSpacing: getHorizontalSize(0.57)))),
                                                              Container(
                                                                  width:
                                                                      getHorizontalSize(
                                                                          51.00),
                                                                  margin: getMargin(
                                                                      top: 11,
                                                                      bottom:
                                                                          45),
                                                                  child: Text(
                                                                      "19 Tue\n1:30",
                                                                      maxLines:
                                                                          null,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .right,
                                                                      style: AppStyle
                                                                          .txtRobotoRegular16Black900
                                                                          .copyWith(
                                                                              letterSpacing: getHorizontalSize(0.57))))
                                                            ])),
                                                    Container(
                                                        height: getVerticalSize(
                                                            1.00),
                                                        width:
                                                            getHorizontalSize(
                                                                371.00),
                                                        margin:
                                                            getMargin(top: 16),
                                                        decoration: BoxDecoration(
                                                            color: ColorConstant
                                                                .gray500))
                                                  ]))
                                        ])),
                                Padding(
                                    padding:
                                        getPadding(left: 2, top: 7, right: 16),
                                    child: ListView.separated(
                                        physics: BouncingScrollPhysics(),
                                        shrinkWrap: true,
                                        separatorBuilder: (context, index) {
                                          return Container(
                                              height: getVerticalSize(1.00),
                                              width: getHorizontalSize(372.00),
                                              decoration: BoxDecoration(
                                                  color:
                                                      ColorConstant.gray500));
                                        },
                                        itemCount: 2,
                                        itemBuilder: (context, index) {
                                          return NotificationsItemWidget();
                                        })),
                                Padding(
                                    padding: getPadding(top: 44),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          CustomImageView(
                                              svgPath: ImageConstant.imgPlay,
                                              height: getVerticalSize(18.00),
                                              width: getHorizontalSize(15.00),
                                              margin: getMargin(
                                                  top: 40, bottom: 41),
                                              onTap: () {
                                                onTapImgPlay(context);
                                              }),
                                          CustomImageView(
                                              svgPath: ImageConstant.imgTicket,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 50,
                                                  top: 37,
                                                  bottom: 38),
                                              onTap: () {
                                                onTapImgTicket(context);
                                              }),
                                          Container(
                                              width: getHorizontalSize(57.00),
                                              margin: getMargin(left: 33),
                                              padding: getPadding(
                                                  left: 16,
                                                  top: 27,
                                                  right: 16,
                                                  bottom: 27),
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(
                                                              19.00)),
                                                  image: DecorationImage(
                                                      image: AssetImage(
                                                          ImageConstant
                                                              .imgGroup38),
                                                      fit: BoxFit.cover)),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgHome,
                                                        height: getSize(24.00),
                                                        width: getSize(24.00),
                                                        onTap: () {
                                                          onTapImgHome(context);
                                                        }),
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Padding(
                                                            padding: getPadding(
                                                                top: 6,
                                                                bottom: 4),
                                                            child: Text("Home",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtZCOOLXiaoWeiRegular10WhiteA700)))
                                                  ])),
                                          CustomImageView(
                                              svgPath: ImageConstant.imgMenu,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 30,
                                                  top: 37,
                                                  bottom: 38),
                                              onTap: () {
                                                onTapImgMenu(context);
                                              }),
                                          CustomImageView(
                                              svgPath:
                                                  ImageConstant.imgBookmark,
                                              height: getSize(24.00),
                                              width: getSize(24.00),
                                              margin: getMargin(
                                                  left: 49,
                                                  top: 37,
                                                  bottom: 38),
                                              onTap: () {
                                                onTapImgBookmark(context);
                                              })
                                        ]))
                              ]))),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                          padding: getPadding(right: 10, bottom: 253),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(left: 2, right: 15),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgImage1,
                                              height: getVerticalSize(74.00),
                                              width: getHorizontalSize(101.00),
                                              margin: getMargin(bottom: 21)),
                                          Container(
                                              width: getHorizontalSize(156.00),
                                              margin: getMargin(top: 16),
                                              child: Text(
                                                  "ALU HUB\nMaintenance Upda...\n\nHello Students, the,",
                                                  maxLines: null,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRegular16Black900
                                                      .copyWith(
                                                          letterSpacing:
                                                              getHorizontalSize(
                                                                  0.57)))),
                                          Container(
                                              width: getHorizontalSize(51.00),
                                              margin: getMargin(
                                                  top: 11, bottom: 45),
                                              child: Text("19 Tue\n1:30",
                                                  maxLines: null,
                                                  textAlign: TextAlign.right,
                                                  style: AppStyle
                                                      .txtRobotoRegular16Black900
                                                      .copyWith(
                                                          letterSpacing:
                                                              getHorizontalSize(
                                                                  0.57))))
                                        ])),
                                Container(
                                    height: getVerticalSize(1.00),
                                    width: getHorizontalSize(364.00),
                                    margin: getMargin(top: 16),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.gray500))
                              ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Padding(
                          padding: getPadding(top: 320, right: 10),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(left: 2, right: 15),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgImage1,
                                              height: getVerticalSize(74.00),
                                              width: getHorizontalSize(101.00),
                                              margin: getMargin(bottom: 21)),
                                          Container(
                                              width: getHorizontalSize(156.00),
                                              margin: getMargin(top: 16),
                                              child: Text(
                                                  "ALU HUB\nMaintenance Upda...\n\nHello Students, the,",
                                                  maxLines: null,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtRobotoRegular16Black900
                                                      .copyWith(
                                                          letterSpacing:
                                                              getHorizontalSize(
                                                                  0.57)))),
                                          Container(
                                              width: getHorizontalSize(51.00),
                                              margin: getMargin(
                                                  top: 11, bottom: 45),
                                              child: Text("19 Tue\n1:30",
                                                  maxLines: null,
                                                  textAlign: TextAlign.right,
                                                  style: AppStyle
                                                      .txtRobotoRegular16Black900
                                                      .copyWith(
                                                          letterSpacing:
                                                              getHorizontalSize(
                                                                  0.57))))
                                        ])),
                                Container(
                                    height: getVerticalSize(1.00),
                                    width: getHorizontalSize(364.00),
                                    margin: getMargin(top: 16),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.gray500))
                              ])))
                ]))));
  }

  onTapImgPlay(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.profileScreen);
  }

  onTapImgTicket(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormScreen);
  }

  onTapImgHome(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homePageScreen);
  }

  onTapImgMenu(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormOneScreen);
  }

  onTapImgBookmark(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.addEventScreen);
  }
}
