import 'package:ccbyalu/core/app_export.dart';
import 'package:flutter/material.dart';

class BookingFormOneScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: size.height,
                width: size.width,
                child: Stack(alignment: Alignment.topCenter, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          width: size.width,
                          padding: getPadding(
                              left: 25, top: 8, right: 25, bottom: 8),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder35),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Spacer(),
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        height: getVerticalSize(25.00),
                                        width: getHorizontalSize(80.00),
                                        decoration: BoxDecoration(
                                            color: ColorConstant.whiteA700))),
                                Container(
                                    height: getVerticalSize(116.00),
                                    width: getHorizontalSize(272.00),
                                    margin: getMargin(left: 13, top: 9),
                                    child: Stack(
                                        alignment: Alignment.bottomRight,
                                        children: [
                                          Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Padding(
                                                  padding: getPadding(
                                                      left: 25, bottom: 4),
                                                  child: Text("PEOPLE",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtZCOOLXiaoWeiRegular20))),
                                          Align(
                                              alignment: Alignment.bottomRight,
                                              child: Padding(
                                                  padding: getPadding(
                                                      right: 21, bottom: 32),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        Text("2",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular40),
                                                        Padding(
                                                            padding: getPadding(
                                                                left: 164),
                                                            child: Text("5",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtZCOOLXiaoWeiRegular40))
                                                      ]))),
                                          Align(
                                              alignment: Alignment.bottomRight,
                                              child: Text("PEOPLE",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtZCOOLXiaoWeiRegular20)),
                                          Align(
                                              alignment: Alignment.topLeft,
                                              child: Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Card(
                                                        clipBehavior:
                                                            Clip.antiAlias,
                                                        elevation: 0,
                                                        margin:
                                                            EdgeInsets.all(0),
                                                        shape: RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        24.00))),
                                                        child: Container(
                                                            height:
                                                                getSize(96.00),
                                                            width:
                                                                getSize(96.00),
                                                            decoration: AppDecoration
                                                                .gradientRed50Red100
                                                                .copyWith(
                                                                    borderRadius:
                                                                        BorderRadiusStyle
                                                                            .circleBorder24),
                                                            child: Stack(
                                                                children: [
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgKisspngchinab,
                                                                      height: getSize(
                                                                          96.00),
                                                                      width: getSize(
                                                                          96.00),
                                                                      radius: BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              24.00)),
                                                                      alignment:
                                                                          Alignment
                                                                              .center)
                                                                ]))),
                                                    Container(
                                                        margin: getMargin(
                                                            left: 24,
                                                            top: 3,
                                                            bottom: 7),
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        24.00))),
                                                        child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Text(
                                                                  "Fireside Chat",
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtZCOOLXiaoWeiRegular18Gray90001),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              30),
                                                                  child: Row(
                                                                      children: [
                                                                        CustomImageView(
                                                                            svgPath:
                                                                                ImageConstant.imgLocation,
                                                                            height: getSize(16.00),
                                                                            width: getSize(16.00),
                                                                            radius: BorderRadius.circular(getHorizontalSize(8.00))),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 8, top: 3),
                                                                            child: Text("Burundi Room, ALU ", overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtZCOOLXiaoWeiRegular13))
                                                                      ])),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          left:
                                                                              24,
                                                                          top:
                                                                              4),
                                                                  child: Text(
                                                                      "12:30 - 1:30",
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtZCOOLXiaoWeiRegular16))
                                                            ]))
                                                  ]))
                                        ])),
                                Padding(
                                    padding:
                                        getPadding(left: 22, top: 8, right: 42),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 4, bottom: 6),
                                          child: Text("Burundi Room",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtZCOOLXiaoWeiRegular15)),
                                      Spacer(),
                                      CustomImageView(
                                          svgPath: ImageConstant
                                              .imgBookmarkWhiteA70026x16,
                                          height: getVerticalSize(26.00),
                                          width: getHorizontalSize(16.00)),
                                      Padding(
                                          padding: getPadding(
                                              left: 25, top: 5, bottom: 5),
                                          child: Text("Leap Pod",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtZCOOLXiaoWeiRegular15))
                                    ])),
                                Container(
                                    height: getVerticalSize(96.00),
                                    width: getHorizontalSize(259.00),
                                    margin: getMargin(left: 13, top: 20),
                                    child: Stack(
                                        alignment: Alignment.bottomRight,
                                        children: [
                                          Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Padding(
                                                  padding: getPadding(
                                                      left: 29, bottom: 11),
                                                  child: Text("20",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtZCOOLXiaoWeiRegular40))),
                                          Align(
                                              alignment: Alignment.bottomRight,
                                              child: Padding(
                                                  padding:
                                                      getPadding(bottom: 11),
                                                  child: Text("10",
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtZCOOLXiaoWeiRegular40))),
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Card(
                                                        clipBehavior:
                                                            Clip.antiAlias,
                                                        elevation: 0,
                                                        margin:
                                                            EdgeInsets.all(0),
                                                        shape: RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        24.00))),
                                                        child: Container(
                                                            height:
                                                                getSize(96.00),
                                                            width:
                                                                getSize(96.00),
                                                            decoration: AppDecoration
                                                                .gradientRed50Red100
                                                                .copyWith(
                                                                    borderRadius:
                                                                        BorderRadiusStyle
                                                                            .circleBorder24),
                                                            child: Stack(
                                                                children: [
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgKisspngchinab,
                                                                      height: getSize(
                                                                          96.00),
                                                                      width: getSize(
                                                                          96.00),
                                                                      radius: BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              24.00)),
                                                                      alignment:
                                                                          Alignment
                                                                              .center)
                                                                ]))),
                                                    Container(
                                                        margin: getMargin(
                                                            left: 24,
                                                            top: 3,
                                                            bottom: 7),
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        24.00))),
                                                        child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Text(
                                                                  "Pride Plus+",
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtZCOOLXiaoWeiRegular18Gray90001),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              30),
                                                                  child: Row(
                                                                      children: [
                                                                        CustomImageView(
                                                                            svgPath:
                                                                                ImageConstant.imgLocation,
                                                                            height: getSize(16.00),
                                                                            width: getSize(16.00),
                                                                            radius: BorderRadius.circular(getHorizontalSize(8.00))),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 8, top: 3),
                                                                            child: Text("Gabon Room, ALU ", overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtZCOOLXiaoWeiRegular13))
                                                                      ])),
                                                              Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                  child: Padding(
                                                                      padding: getPadding(
                                                                          top:
                                                                              4),
                                                                      child: Text(
                                                                          "12:30 - 1:30",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtZCOOLXiaoWeiRegular16)))
                                                            ]))
                                                  ]))
                                        ])),
                                Padding(
                                    padding: getPadding(right: 24),
                                    child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgBookmarkWhiteA700,
                                              height: getVerticalSize(24.00),
                                              width: getHorizontalSize(16.00),
                                              margin: getMargin(top: 22)),
                                          Padding(
                                              padding: getPadding(left: 12),
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Text("PEOPLE",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtZCOOLXiaoWeiRegular20),
                                                    Text("PEOPLE",
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtZCOOLXiaoWeiRegular20),
                                                    Align(
                                                        alignment: Alignment
                                                            .centerLeft,
                                                        child: Text(
                                                            "Lagos Room",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular15))
                                                  ])),
                                          Spacer(),
                                          Padding(
                                              padding: getPadding(bottom: 2),
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Padding(
                                                        padding: getPadding(
                                                            right: 7),
                                                        child: Text("PEOPLE",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular20)),
                                                    Padding(
                                                        padding:
                                                            getPadding(top: 9),
                                                        child: Text(
                                                            "Namibia Room",
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtZCOOLXiaoWeiRegular15))
                                                  ]))
                                        ])),
                                Container(
                                    height: getVerticalSize(96.00),
                                    width: getHorizontalSize(282.00),
                                    margin: getMargin(left: 13, top: 37),
                                    child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Align(
                                              alignment: Alignment.bottomRight,
                                              child: Container(
                                                  width:
                                                      getHorizontalSize(257.00),
                                                  margin: getMargin(right: 1),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        Padding(
                                                            padding: getPadding(
                                                                right: 31),
                                                            child: Text("1",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtZCOOLXiaoWeiRegular40)),
                                                        Padding(
                                                            padding: getPadding(
                                                                top: 2),
                                                            child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                children: [
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          bottom:
                                                                              4),
                                                                      child: Text(
                                                                          "PEOPLE",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtZCOOLXiaoWeiRegular20)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              115,
                                                                          top:
                                                                              4),
                                                                      child: Text(
                                                                          "PERSON",
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtZCOOLXiaoWeiRegular20))
                                                                ]))
                                                      ]))),
                                          Align(
                                              alignment: Alignment.center,
                                              child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Card(
                                                        clipBehavior:
                                                            Clip.antiAlias,
                                                        elevation: 0,
                                                        margin:
                                                            EdgeInsets.all(0),
                                                        shape: RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        24.00))),
                                                        child: Container(
                                                            height:
                                                                getSize(96.00),
                                                            width:
                                                                getSize(96.00),
                                                            decoration: AppDecoration
                                                                .gradientRed50Red100
                                                                .copyWith(
                                                                    borderRadius:
                                                                        BorderRadiusStyle
                                                                            .circleBorder24),
                                                            child: Stack(
                                                                children: [
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgKisspngchinab,
                                                                      height: getSize(
                                                                          96.00),
                                                                      width: getSize(
                                                                          96.00),
                                                                      radius: BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              24.00)),
                                                                      alignment:
                                                                          Alignment
                                                                              .center)
                                                                ]))),
                                                    Container(
                                                        margin: getMargin(
                                                            left: 24,
                                                            top: 4,
                                                            bottom: 7),
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(
                                                                        24.00))),
                                                        child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Text(
                                                                  "Choosing your Major",
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtZCOOLXiaoWeiRegular18Gray90001),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          top:
                                                                              29),
                                                                  child: Row(
                                                                      children: [
                                                                        CustomImageView(
                                                                            svgPath:
                                                                                ImageConstant.imgLocation,
                                                                            height: getSize(16.00),
                                                                            width: getSize(16.00),
                                                                            radius: BorderRadius.circular(getHorizontalSize(8.00))),
                                                                        Padding(
                                                                            padding:
                                                                                getPadding(left: 8, top: 3),
                                                                            child: Text("Lagos Room, ALU Hub", overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtZCOOLXiaoWeiRegular13))
                                                                      ])),
                                                              Padding(
                                                                  padding:
                                                                      getPadding(
                                                                          left:
                                                                              24,
                                                                          top:
                                                                              4),
                                                                  child: Text(
                                                                      "12:30 - 1:30",
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtZCOOLXiaoWeiRegular16))
                                                            ]))
                                                  ]))
                                        ])),
                                Padding(
                                    padding: getPadding(right: 27),
                                    child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        children: [
                                          CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgBookmarkWhiteA700,
                                              height: getVerticalSize(24.00),
                                              width: getHorizontalSize(16.00),
                                              margin: getMargin(bottom: 4)),
                                          Padding(
                                              padding: getPadding(
                                                  left: 11, top: 8, bottom: 4),
                                              child: Text("Gambia Room",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtZCOOLXiaoWeiRegular15)),
                                          Spacer(),
                                          CustomImageView(
                                              svgPath: ImageConstant
                                                  .imgBookmarkWhiteA70026x16,
                                              height: getVerticalSize(26.00),
                                              width: getHorizontalSize(16.00),
                                              margin: getMargin(top: 2)),
                                          Padding(
                                              padding: getPadding(
                                                  left: 12, top: 8, bottom: 4),
                                              child: Text("Guinea Room",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtZCOOLXiaoWeiRegular15))
                                        ])),
                                Align(
                                    alignment: Alignment.center,
                                    child: Padding(
                                        padding: getPadding(top: 24),
                                        child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgPlay,
                                                  height:
                                                      getVerticalSize(18.00),
                                                  width:
                                                      getHorizontalSize(15.00),
                                                  margin: getMargin(
                                                      top: 40, bottom: 41),
                                                  onTap: () {
                                                    onTapImgPlay(context);
                                                  }),
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgTicket,
                                                  height: getSize(24.00),
                                                  width: getSize(24.00),
                                                  margin: getMargin(
                                                      left: 50,
                                                      top: 37,
                                                      bottom: 38),
                                                  onTap: () {
                                                    onTapImgTicket(context);
                                                  }),
                                              Container(
                                                  width:
                                                      getHorizontalSize(57.00),
                                                  margin: getMargin(left: 33),
                                                  padding: getPadding(
                                                      left: 16,
                                                      top: 27,
                                                      right: 16,
                                                      bottom: 27),
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              getHorizontalSize(
                                                                  19.00)),
                                                      image: DecorationImage(
                                                          image: AssetImage(
                                                              ImageConstant
                                                                  .imgGroup38),
                                                          fit: BoxFit.cover)),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        CustomImageView(
                                                            svgPath:
                                                                ImageConstant
                                                                    .imgHome,
                                                            height:
                                                                getSize(24.00),
                                                            width:
                                                                getSize(24.00),
                                                            onTap: () {
                                                              onTapImgHome(
                                                                  context);
                                                            }),
                                                        Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Padding(
                                                                padding:
                                                                    getPadding(
                                                                        top: 6,
                                                                        bottom:
                                                                            4),
                                                                child: Text(
                                                                    "Home",
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtZCOOLXiaoWeiRegular10WhiteA700)))
                                                      ])),
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgMenu,
                                                  height: getSize(24.00),
                                                  width: getSize(24.00),
                                                  margin: getMargin(
                                                      left: 30,
                                                      top: 37,
                                                      bottom: 38)),
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgBookmark,
                                                  height: getSize(24.00),
                                                  width: getSize(24.00),
                                                  margin: getMargin(
                                                      left: 49,
                                                      top: 37,
                                                      bottom: 38),
                                                  onTap: () {
                                                    onTapImgBookmarkFour(
                                                        context);
                                                  })
                                            ])))
                              ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          height: getVerticalSize(157.00),
                          width: size.width,
                          child: Stack(alignment: Alignment.center, children: [
                            CustomImageView(
                                imagePath: ImageConstant.imgEllipse7562,
                                height: getVerticalSize(157.00),
                                width: getHorizontalSize(375.00),
                                alignment: Alignment.center),
                            Align(
                                alignment: Alignment.center,
                                child: Text("Events Page",
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle
                                        .txtZCOOLXiaoWeiRegular28WhiteA700))
                          ])))
                ]))));
  }

  onTapImgPlay(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.profileScreen);
  }

  onTapImgTicket(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormScreen);
  }

  onTapImgHome(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homePageScreen);
  }

  onTapImgBookmarkFour(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.addEventScreen);
  }
}
