import 'package:ccbyalu/core/app_export.dart';
import 'package:ccbyalu/widgets/custom_drop_down.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class AddEventScreen extends StatelessWidget {
  List<String> dropdownItemList = ["Item One", "Item Two", "Item Three"];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            body: Container(
                height: size.height,
                width: size.width,
                child: Stack(alignment: Alignment.topCenter, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          width: size.width,
                          padding:
                              getPadding(left: 3, top: 8, right: 3, bottom: 8),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder35),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomImageView(
                                    svgPath: ImageConstant.imgFrame,
                                    height: getSize(22.00),
                                    width: getSize(22.00),
                                    margin: getMargin(left: 27, top: 41)),
                                CustomImageView(
                                    svgPath: ImageConstant.imgBookmarkWhiteA700,
                                    height: getVerticalSize(24.00),
                                    width: getHorizontalSize(16.00),
                                    margin: getMargin(left: 52, top: 86)),
                                Spacer(),
                                Padding(
                                    padding: getPadding(left: 5),
                                    child: Text("Description",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtAbhayaLibreExtraBold25Bluegray900)),
                                Container(
                                    height: getVerticalSize(86.00),
                                    width: getHorizontalSize(286.00),
                                    margin: getMargin(left: 29, top: 15),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.blueGray100)),
                                Container(
                                    height: getVerticalSize(78.00),
                                    width: getHorizontalSize(362.00),
                                    margin: getMargin(top: 8),
                                    child: Stack(
                                        alignment: Alignment.bottomRight,
                                        children: [
                                          Align(
                                              alignment: Alignment.center,
                                              child: Padding(
                                                  padding: getPadding(right: 7),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        Padding(
                                                            padding: getPadding(
                                                                left: 9),
                                                            child: Text(
                                                                "Location",
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtAbhayaLibreExtraBold25Bluegray900)),
                                                        Padding(
                                                            padding: getPadding(
                                                                left: 5,
                                                                top: 13),
                                                            child: Row(
                                                                children: [
                                                                  Text(
                                                                      "ALU CAMPUS",
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtRobotoRegular16Black900
                                                                          .copyWith(
                                                                              letterSpacing: getHorizontalSize(0.57))),
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowdown,
                                                                      height: getVerticalSize(
                                                                          8.00),
                                                                      width: getHorizontalSize(
                                                                          20.00),
                                                                      margin: getMargin(
                                                                          left:
                                                                              19,
                                                                          top:
                                                                              6,
                                                                          bottom:
                                                                              4)),
                                                                  Spacer(),
                                                                  Text(
                                                                      "Burundi Room",
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .left,
                                                                      style: AppStyle
                                                                          .txtRobotoRegular16Black900
                                                                          .copyWith(
                                                                              letterSpacing: getHorizontalSize(0.57))),
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowdown,
                                                                      height: getVerticalSize(
                                                                          8.00),
                                                                      width: getHorizontalSize(
                                                                          20.00),
                                                                      margin: getMargin(
                                                                          left:
                                                                              14,
                                                                          top:
                                                                              6,
                                                                          bottom:
                                                                              4))
                                                                ])),
                                                        Container(
                                                            height:
                                                                getVerticalSize(
                                                                    3.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    158.00),
                                                            margin: getMargin(
                                                                top: 13),
                                                            decoration: BoxDecoration(
                                                                color: ColorConstant
                                                                    .blueGray100))
                                                      ]))),
                                          Align(
                                              alignment: Alignment.bottomRight,
                                              child: Container(
                                                  height: getVerticalSize(3.00),
                                                  width:
                                                      getHorizontalSize(158.00),
                                                  margin: getMargin(bottom: 2),
                                                  decoration: BoxDecoration(
                                                      color: ColorConstant
                                                          .blueGray100)))
                                        ])),
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        width: getHorizontalSize(314.00),
                                        margin: getMargin(top: 49),
                                        padding: getPadding(
                                            left: 30,
                                            top: 7,
                                            right: 117,
                                            bottom: 7),
                                        decoration: AppDecoration
                                            .txtFillGray90002
                                            .copyWith(
                                                borderRadius: BorderRadiusStyle
                                                    .txtCircleBorder20),
                                        child: Text("Upload",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtZCOOLXiaoWeiRegular20))),
                                Align(
                                    alignment: Alignment.center,
                                    child: Padding(
                                        padding: getPadding(top: 30),
                                        child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgPlay,
                                                  height:
                                                      getVerticalSize(18.00),
                                                  width:
                                                      getHorizontalSize(15.00),
                                                  margin: getMargin(
                                                      top: 40, bottom: 41),
                                                  onTap: () {
                                                    onTapImgPlay(context);
                                                  }),
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgTicket,
                                                  height: getSize(24.00),
                                                  width: getSize(24.00),
                                                  margin: getMargin(
                                                      left: 50,
                                                      top: 37,
                                                      bottom: 38),
                                                  onTap: () {
                                                    onTapImgTicket(context);
                                                  }),
                                              Container(
                                                  width:
                                                      getHorizontalSize(57.00),
                                                  margin: getMargin(left: 33),
                                                  padding: getPadding(
                                                      left: 16,
                                                      top: 27,
                                                      right: 16,
                                                      bottom: 27),
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              getHorizontalSize(
                                                                  19.00)),
                                                      image: DecorationImage(
                                                          image: AssetImage(
                                                              ImageConstant
                                                                  .imgGroup38),
                                                          fit: BoxFit.cover)),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        CustomImageView(
                                                            svgPath:
                                                                ImageConstant
                                                                    .imgHome,
                                                            height:
                                                                getSize(24.00),
                                                            width:
                                                                getSize(24.00),
                                                            onTap: () {
                                                              onTapImgHome(
                                                                  context);
                                                            }),
                                                        Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Padding(
                                                                padding:
                                                                    getPadding(
                                                                        top: 6,
                                                                        bottom:
                                                                            4),
                                                                child: Text(
                                                                    "Home",
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtZCOOLXiaoWeiRegular10WhiteA700)))
                                                      ])),
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgMenu,
                                                  height: getSize(24.00),
                                                  width: getSize(24.00),
                                                  margin: getMargin(
                                                      left: 30,
                                                      top: 37,
                                                      bottom: 38),
                                                  onTap: () {
                                                    onTapImgMenu(context);
                                                  }),
                                              CustomImageView(
                                                  svgPath:
                                                      ImageConstant.imgBookmark,
                                                  height: getSize(24.00),
                                                  width: getSize(24.00),
                                                  margin: getMargin(
                                                      left: 49,
                                                      top: 37,
                                                      bottom: 38))
                                            ])))
                              ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Padding(
                          padding: getPadding(top: 184, right: 1),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(left: 12),
                                    child: Text("Title",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtAbhayaLibreExtraBold25Bluegray900)),
                                Container(
                                    height: getVerticalSize(3.00),
                                    width: getHorizontalSize(374.00),
                                    margin: getMargin(top: 36),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.blueGray100))
                              ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          height: getVerticalSize(25.00),
                          width: getHorizontalSize(80.00),
                          margin: getMargin(top: 169),
                          decoration:
                              BoxDecoration(color: ColorConstant.whiteA700))),
                  Align(
                      alignment: Alignment.topLeft,
                      child: Padding(
                          padding: getPadding(left: 95, top: 154),
                          child: Text("Burundi Room",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style:
                                  AppStyle.txtZCOOLXiaoWeiRegular28WhiteA700))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Padding(
                          padding: getPadding(top: 275, right: 5),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(left: 12),
                                    child: Text("Start",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtAbhayaLibreExtraBold25Bluegray900)),
                                CustomDropDown(
                                    width: 307,
                                    focusNode: FocusNode(),
                                    icon: Container(
                                        margin: getMargin(left: 30),
                                        child: CustomImageView(
                                            svgPath:
                                                ImageConstant.imgArrowdown)),
                                    hintText: "02/13/2023 1:15PM",
                                    margin: getMargin(top: 6),
                                    alignment: Alignment.center,
                                    items: dropdownItemList,
                                    onChanged: (value) {}),
                                Container(
                                    height: getVerticalSize(3.00),
                                    width: getHorizontalSize(370.00),
                                    margin: getMargin(top: 12),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.blueGray100))
                              ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          height: getVerticalSize(157.00),
                          width: size.width,
                          child:
                              Stack(alignment: Alignment.topCenter, children: [
                            CustomImageView(
                                imagePath: ImageConstant.imgEllipse7563,
                                height: getVerticalSize(157.00),
                                width: getHorizontalSize(375.00),
                                alignment: Alignment.center),
                            Align(
                                alignment: Alignment.topCenter,
                                child: Padding(
                                    padding: getPadding(top: 60),
                                    child: Text("Add An Event",
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtZCOOLXiaoWeiRegular28WhiteA700)))
                          ])))
                ]))));
  }

  onTapImgPlay(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.profileScreen);
  }

  onTapImgTicket(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormScreen);
  }

  onTapImgHome(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homePageScreen);
  }

  onTapImgMenu(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.bookingFormOneScreen);
  }
}
