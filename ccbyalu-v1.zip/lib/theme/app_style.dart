import 'package:flutter/material.dart';
import 'package:ccbyalu/core/app_export.dart';

class AppStyle {
  static TextStyle txtZCOOLXiaoWeiRegular20Gray900 = TextStyle(
    color: ColorConstant.gray900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular20 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular28 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      28,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular24 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      24,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAbhayaLibreExtraBold25 = TextStyle(
    color: ColorConstant.gray90002,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Abhaya Libre ExtraBold',
    fontWeight: FontWeight.w800,
  );

  static TextStyle txtZCOOLXiaoWeiRegular18Gray90001 = TextStyle(
    color: ColorConstant.gray90001,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular14Bluegray300 = TextStyle(
    color: ColorConstant.blueGray300,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular40 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular22 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      22,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular13 = TextStyle(
    color: ColorConstant.blueGray300,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular34 = TextStyle(
    color: ColorConstant.gray900,
    fontSize: getFontSize(
      34,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAbhayaLibreExtraBold25Bluegray900 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Abhaya Libre ExtraBold',
    fontWeight: FontWeight.w800,
  );

  static TextStyle txtZCOOLXiaoWeiRegular15 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular14 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular16Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular10 = TextStyle(
    color: ColorConstant.gray900,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular28WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      28,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular17 = TextStyle(
    color: ColorConstant.gray900,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular16Bluegray400 = TextStyle(
    color: ColorConstant.bluegray400,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular16 = TextStyle(
    color: ColorConstant.gray90001,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular18 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular16WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular16 = TextStyle(
    color: ColorConstant.teal400,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular18 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtZCOOLXiaoWeiRegular10WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: '?????',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtCabinRegular28 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      28,
    ),
    fontFamily: 'Cabin',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAbhayaLibreExtraBold25Indigo50099 = TextStyle(
    color: ColorConstant.indigo50099,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Abhaya Libre ExtraBold',
    fontWeight: FontWeight.w800,
  );
}
